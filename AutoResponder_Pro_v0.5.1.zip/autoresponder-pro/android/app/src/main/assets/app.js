/* AutoResponder Pro v0.5.1 — selector Android de contactos, alta por número y mobile fix. */
(() => {
  'use strict';
  const KEY = 'autoresponder_pro_v1';
  const $ = (sel) => document.querySelector(sel);
  const el = (tag, props = {}) => Object.assign(document.createElement(tag), props);
  const safe = (str) => String(str == null ? '' : str).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const short = (t, n = 90) => String(t || '').slice(0, n);
  const native = !!(window.AndroidBridge && typeof window.AndroidBridge.shareText === 'function');
  const SE=window.ScheduleEngine;
  if (!SE) throw Error('Falta el motor local de horarios.');
  const assistants = {auto:'✨ Detectar negocio',movieplay:'🎬 MoviePlay',tresm:'🍔 Las Tres M',personal:'🤖 Personalizado',none:'⛔ No responder'};
  const channelNames = {normal:'WhatsApp normal',business:'WhatsApp Business'};
  const defaults = () => ({
    version:1, channel:{normal:{enabled:false,assistant:'auto'},business:{enabled:false,assistant:'auto'}},
    assistants:{movieplay:{active:true},tresm:{active:true},personal:{active:true}},
    exceptions:[], allowlist:[], blocked:[], paused:[],
    rules:[
      {id:'r1',assistant:'movieplay',keywords:'netflix,precio netflix,planes netflix,netflix 4k',response:'¡Hola! 👋🎬 Estos son nuestros planes de Netflix Premium 4K:\n\n• 26 días — $14.000\n• 28 días — $16.000\n• 30 días — $18.000\n\n¿Cuál te interesa?',imageTag:'netflix',active:true},
      {id:'r2',assistant:'movieplay',keywords:'horario,atencion,soporte,atienden',response:'¡Hola! 👋 Nuestro horario de soporte es de lunes a sábado de 9:00 a. m. a 10:00 p. m. y domingos y festivos de 9:00 a. m. a 5:00 p. m. Ventas: todos los días de 9:00 a. m. a 10:00 p. m.',imageTag:'horario',active:true},
      {id:'r3',assistant:'tresm',keywords:'horario,abren,abierto,ubicacion,donde quedan',response:'¡Hola! 🍔 Somos Las Tres M, en el barrio Ciudadela de La Ceja. Atendemos sábados y domingos de 6:00 p. m. a 10:30 p. m. Puedes ver nuestro menú y hacer tu pedido en https://lastresm.netlify.app',imageTag:'horario tresm',active:true},
      {id:'r4',assistant:'tresm',keywords:'menu,carta,comidas,hamburguesa,perro,patacon',response:'¡Hola! 🍔 Tenemos hamburguesas, perros, chuzos, arepas y más. Consulta nuestro menú actualizado aquí: https://lastresm.netlify.app. ¿Qué se te antoja?',imageTag:'menu',active:true},
      {id:'r5',assistant:'personal',keywords:'hola,buenos dias,buenas tardes,buenas noches',response:'¡Hola! 👋 Gracias por escribirme. Te responderé personalmente en cuanto pueda.',imageTag:'',active:true}
    ],images:[],schedules:SE.defaultSchedules(),scheduleOverrides:[],settings:{requireAllowlist:true,blockGroups:true,reviewOnly:true,autoReplies:{normal:false,business:false}},
    inbox:[]
  });
  function readConfig(){
    try { const obj = JSON.parse(localStorage.getItem(KEY)||'null'); if(obj && obj.version===1 && obj.channel && Array.isArray(obj.rules)) return obj; }
    catch(_e) {} return defaults();
  }
  let state = readConfig();
  function migrateScheduleConfig(){
    const fresh=SE.defaultSchedules();
    state.schedules=state.schedules||fresh;
    for(const group of ['movieplay','tresm'])for(const unit of Object.keys(fresh[group])){
      state.schedules[group] ||= {};
      state.schedules[group][unit] ||= JSON.parse(JSON.stringify(fresh[group][unit]));
      state.schedules[group][unit].days ||= JSON.parse(JSON.stringify(fresh[group][unit].days));
      for(let d=0;d<7;d++)state.schedules[group][unit].days[d] ||= JSON.parse(JSON.stringify(fresh[group][unit].days[d]));
    }
    state.scheduleOverrides ||= [];
  }
  migrateScheduleConfig();
  state.settings ||= defaults().settings;
  state.settings.autoReplies ||= {normal:false,business:false};
  const runtime = {route:'inicio',testReply:null,testImage:null,selectedInbox:null,review:null,pendingImage:null,openSchedules:new Set()};
  const save = () => {localStorage.setItem(KEY,JSON.stringify(state));syncNativeCapture();};
  const token = () => 'id_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,6);
  const opts = (v) => Object.keys(assistants).map(k => `<option value="${k}" ${k===v?'selected':''}>${assistants[k]}</option>`).join('');
  function notify(text) {const n=$('#toast'); n.textContent=text;n.classList.add('show');clearTimeout(notify.t);notify.t=setTimeout(()=>n.classList.remove('show'),2800);}
  const headings = {automatizacion:['ANDROID / RESPUESTAS','Respuestas automáticas'],inicio:['GENERAL / INICIO','Centro de control'],horarios:['GESTIÓN / HORARIOS','Horarios y festivos'],asistentes:['GESTIÓN / ASISTENTES','Asistentes'],contactos:['GESTIÓN / CONTACTOS','Excepciones y permisos'],reglas:['CONTENIDO / REGLAS','Respuestas configuradas'],imagenes:['CONTENIDO / MULTIMEDIA','Biblioteca de imágenes'],bandeja:['MENSAJES / REVISIÓN','Bandeja de revisión'],pruebas:['CALIDAD / SIMULACIÓN','Probador de respuestas'],ajustes:['SISTEMA / AJUSTES','Configuración']};
  function setRoute(route){
    if(!headings[route])return;
    runtime.route=route;
    $('#pageTitle').textContent=headings[route][1];$('#breadcrumb').textContent=headings[route][0];
    document.querySelectorAll('.navbtn').forEach(n=>n.classList.toggle('active',n.dataset.route===route));
    $('.sidebar').classList.remove('open');render();
  }
  function stat(label,value,sub,icon){return `<article class="card"><div class="between"><span class="circle">${icon}</span><span class="pill">LOCAL</span></div><div class="metric">${safe(value)}</div><div class="metric-label">${safe(label)}</div><div class="small muted top-space">${safe(sub)}</div></article>`;}
  const labelFor=(a)=>assistants[a]||'⚠️ Negocio por confirmar';
  // Contact fields may originate from WhatsApp notifications or the Android phone picker.
  // A typed phone number is accepted even if there is no entry in Android Contacts.
  // Unverified numbers cannot identify a notification displaying only a saved alias.
  const phoneKey=(raw)=>{
    const value=String(raw||'').replace(/\D/g,'');
    if (value.length===12 && value.startsWith('57')) return value.slice(2);
    return value.length>=7&&value.length<=15?value:'';
  };
  const sameContact=(entry,incoming)=>{
    const received=String(incoming||'').trim();
    if (!received) return false;
    if ([entry.contact,entry.phone].filter(Boolean).some(v=>normalize(v)===normalize(received))) return true;
    const receivedPhone=phoneKey(received);
    return !!receivedPhone && [entry.phone,entry.contact].some(v=>phoneKey(v)===receivedPhone);
  };
  const allowText=(contact,channel)=> `${channel}:${contact.trim().toLocaleLowerCase('es')}`;
  function assignmentFor(channel,contact,message=''){
    return SE.resolveAssignment(channel,contact,message,state.channel,state.exceptions);
  }
  function assistantFor(channel,contact,message=''){
    return assignmentFor(channel,contact,message).assistant;
  }
  const departmentName=(assistant,unit)=> SE.units.find(x=>x.assistant===assistant&&x.unit===unit)?.label || labelFor(assistant);
  function departmentStatus(assistant,unit,at=new Date()){
    return SE.evaluate(state.schedules,state.scheduleOverrides,assistant,unit,at);
  }
  function authorized(channel,contact){return state.allowlist.some(x=>x.channel===channel&&sameContact(x,contact));}
  function isBlocked(channel,contact){return state.blocked.some(x=>x.channel===channel&&sameContact(x,contact));}
  const normalize=(t)=>String(t||'').toLocaleLowerCase('es').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim();
  const localDate=()=>{const d=new Date();return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');};
  const isImageValid=(i,day=localDate())=>!!i?.active && (!i.validFrom || i.validFrom<=day) && (!i.validUntil || i.validUntil>=day);
  function pickImage(assistant,tag,day=localDate()){
    if(!normalize(tag))return null;
    const wanted=normalize(tag);
    return state.images.filter(i=>i.assistant===assistant && isImageValid(i,day)).map(i=>{
      const tags=String(i.tags||'').split(',').map(normalize).filter(Boolean);
      const score=tags.reduce((n,t)=>Math.max(n,t===wanted?100:t.includes(wanted)||wanted.includes(t)?Math.min(t.length,60):0),0);
      return {image:i,score};
    }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score || (b.image.createdAt||0)-(a.image.createdAt||0))[0]?.image||null;
  }
  function respond(channel,contact,text,group=false,at=new Date()){
    if (!state.channel[channel]?.enabled) return {reason:'Este canal está desactivado.'};
    if (!contact.trim() || !text.trim()) return {reason:'Falta el contacto o el mensaje.'};
    if (state.settings.blockGroups && group) return {reason:'Los grupos están excluidos.'};
    if (isBlocked(channel,contact)) return {reason:'Contacto bloqueado para el asistente.'};
    if ((state.paused||[]).some(x=>x.channel===channel&&sameContact(x,contact)&&x.until>Date.now())) return {reason:'Conversación pausada manualmente.'};
    if (state.settings.requireAllowlist && !authorized(channel,contact)) return {reason:'Contacto sin permiso: agréguelo a la lista de pruebas.'};
    const msg=normalize(text);
    if (/\b(otp|pin|clave|contrasena|password|codigo de acceso|verificacion bancaria)\b/.test(msg)) return {reason:'Por seguridad no se generan respuestas a mensajes con claves o códigos.'};
    const assign=assignmentFor(channel,contact,text);
    if(assign.method==='clarify')return {
      reply:'¡Hola! 👋 Gracias por escribir. ¿Tu consulta es para 🎬 MoviePlay o para 🍔 Las Tres M? Así te compartimos la información y el horario correctos.',
      assistant:null,unit:null,method:'clarify',requiresSelection:true,image:null
    };
    const assistant=assign.assistant;
    if(assistant==='none' || !state.assistants[assistant]?.active)return {reason:'No hay un asistente habilitado para ese contacto.'};
    const unit=SE.determineUnit(assistant,text);
    if(unit){
      const status=departmentStatus(assistant,unit,at);
      if(!status.open)return {
        reply:status.away || 'Gracias por escribirnos. Estamos fuera de nuestro horario y te atenderemos cuando abramos.',
        assistant,unit,method:assign.method,status:'closed',schedule:status,image:null
      };
    }
    const rules=state.rules.filter(r=>r.active && r.assistant===assistant);
    let best=null,bestScore=0;
    for(const rule of rules){
      const keys=rule.keywords.split(',').map(normalize).filter(Boolean);
      const score=keys.reduce((acc,k)=>acc+(msg.includes(k)?Math.max(k.length,4):0),0);
      if(score>bestScore){bestScore=score;best=rule;}
    }
    if(!best)return {reason:'No existe una regla confiable. Revisión humana necesaria.',assistant,unit};
    const img=pickImage(assistant,best.imageTag,SE.bogotaParts(at).date);
    return {reply:best.response,assistant,unit,method:assign.method,status:'open',schedule:unit?departmentStatus(assistant,unit,at):null,rule:best.id,image:img||null};
  }
  function renderSchedules(){
    const now=SE.bogotaParts();
    const formatDay=(d)=>SE.days[d];
    const entries=SE.units.map(meta=>{
      const sc=state.schedules[meta.assistant]?.[meta.unit],status=departmentStatus(meta.assistant,meta.unit);
      const rows=Array.from({length:7},(_,d)=>{
        const rule=sc.days[d];
        return `<div class="dayrow" data-day="${d}"><label class="daylabel"><input type="checkbox" data-day-enabled="${meta.id}:${d}" ${rule.enabled?'checked':''}>${formatDay(d)}</label><div class="timepair"><input type="time" aria-label="Apertura ${formatDay(d)}" data-day-start="${meta.id}:${d}" value="${safe(rule.start)}" ${!rule.enabled?'disabled':''}><span>—</span><input type="time" aria-label="Cierre ${formatDay(d)}" data-day-end="${meta.id}:${d}" value="${safe(rule.end)}" ${!rule.enabled?'disabled':''}></div></div>`;
      }).join('');
      return `<article class="card sched-card"><div class="between"><div><div class="small muted">${meta.icon} ${safe(meta.label)}</div><h2>${safe(meta.label.split(' · ')[1])}</h2></div><span class="pill ${status.open?'':'off'}">${status.open?'Abierto ahora':'Cerrado ahora'}</span></div><p class="small muted">Horario de Bogotá · ${safe(status.label)} · ${safe(status.reason)}</p><details class="schedule-details" data-schedule-details="${meta.id}" ${runtime.openSchedules.has(meta.id)?'open':''}><summary>Editar días, festivos y mensaje de ausencia <span>⌄</span></summary><div class="daygrid">${rows}</div>${meta.unit==='support'?`<label class="between small toggle-row"><span>En festivos de Colombia usar el horario del domingo</span><input class="toggle" type="checkbox" data-holiday-mode="${meta.id}" ${sc.holidayMode==='sunday'?'checked':''}></label>`:''}<div class="form-control top-space"><label>Mensaje fuera de horario</label><textarea data-away="${meta.id}" rows="4">${safe(sc.away)}</textarea></div><p class="tiny muted">Se guarda automáticamente al modificar un campo.</p></details></article>`;
    }).join('');
    const year=now.year;
    const upcoming=[...SE.holidays(year),...SE.holidays(year+1)].filter(x=>x.date>=now.date).slice(0,5);
    return `<div class="hero-schedule"><div><span class="pill">AMERICA/BOGOTA · UTC−5</span><h2>Un horario para cada tipo de atención</h2><p>MoviePlay Ventas, MoviePlay Soporte y Las Tres M no comparten horario. La fecha festiva solo modifica el soporte de MoviePlay.</p></div><button class="btn soft" data-go="pruebas">Probar horario →</button></div>
      <div class="grid cols3 schedule-grid">${entries}</div>
      <div class="section split"><article class="card stack"><div class="between"><h2>Excepciones y cierres especiales</h2><span class="pill">Prioridad máxima</span></div><p class="small muted">Úsalas para festivos con atención especial, cierres por motivos personales o cambios de turno.</p>
      <div class="form-control"><label>Área que cambia</label><select id="ovUnit">${SE.units.map(x=>`<option value="${x.id}">${safe(x.label)}</option>`).join('')}</select></div>
      <div class="form-control"><label>Fecha</label><input class="field" type="date" id="ovDate" value="${now.date}"></div>
      <div class="form-control"><label>Qué ocurrirá</label><select id="ovMode"><option value="closed">No habrá atención</option><option value="hours">Horario especial</option></select></div>
      <div class="grid cols2" id="ovTimes" hidden><div class="form-control"><label>Abre</label><input class="field" type="time" id="ovStart" value="18:00"></div><div class="form-control"><label>Cierra</label><input class="field" type="time" id="ovEnd" value="22:30"></div></div>
      <div class="form-control"><label>Motivo interno (opcional)</label><input class="field" id="ovNote" maxlength="100" placeholder="Ej. Cierre por motivos personales"></div>
      <button class="btn primary" data-action="save-override">+ Guardar excepción</button>
      <div class="divider"></div><h2>Fechas personalizadas</h2>
      ${state.scheduleOverrides.length?state.scheduleOverrides.slice().sort((a,b)=>a.date.localeCompare(b.date)).map(x=>`<div class="contact-line"><div><strong>${safe(x.date)} · ${safe(departmentName(x.assistant,x.unit))}</strong><small>${x.mode==='closed'?'Cerrado':safe(x.start+'–'+x.end)}${x.note?' · '+safe(x.note):''}</small></div><button class="btn mini danger" data-delete-override="${safe(x.id)}">Quitar</button></div>`).join(''):'<div class="empty">No hay cambios especiales guardados.</div>'}
      </article><article class="card stack"><h2>Festivos de Colombia</h2><p class="small muted">Se calculan localmente. Para MoviePlay Soporte los festivos usan el horario del domingo, incluso si caen entre semana.</p>
      ${upcoming.map(x=>`<div class="holiday-item"><strong>${safe(x.date)}</strong><span>${safe(x.name)}</span></div>`).join('')}
      <div class="notice">Si Las Tres M abre un festivo entre semana, programa una excepción de «Horario especial». No se abrirá por defecto.</div>
      </article></div>`;
  }
  function renderHome(){
    return `<div class="home-intro"><div><span class="pill">NUEVO · CONTROL MULTIEMPRESA</span><h2>Un solo panel, tres horarios separados.</h2><p class="small muted">Configura cada negocio sin cruzar sus mensajes. Ambos WhatsApp pueden detectar MoviePlay o Las Tres M por la consulta.</p></div><div class="row"><button class="btn primary" data-action="use-mixed">Activar detección en ambos</button><button class="btn soft" data-go="horarios">Gestionar horarios →</button></div></div><div class="grid cols3">${stat('Canales habilitados',Object.values(state.channel).filter(x=>x.enabled).length+'/2','Ambos se administran por separado','↗')}${stat('Asistentes activos',Object.values(state.assistants).filter(x=>x.active).length,'Cada uno mantiene sus reglas','◉')}${stat('Imágenes guardadas',state.images.length,'En tu navegador o app Android','▧')}</div>
    <div class="section"><div class="card between auto-highlight"><div><h2>Respuestas automáticas de texto</h2><p class="small muted">Configúralas por WhatsApp; solo para contactos autorizados. Inician apagadas.</p></div><div class="row"><button class="btn primary" data-go="automatizacion">Configurar →</button><button class="btn danger" data-action="stop-auto">Detener autoenvío</button></div></div></div>
    <div class="section split"><div class="card"><div class="between"><h2>Canales de WhatsApp</h2><span class="pill">Independientes</span></div><p class="small muted">Activa primero la captura. El envío automático de texto tiene un interruptor adicional, independiente por WhatsApp.</p>${['normal','business'].map(ch=>`<div class="contact-line"><div><strong>${channelNames[ch]}</strong><small>Asistente: ${labelFor(state.channel[ch].assistant)}</small></div><input class="toggle" aria-label="Habilitar ${channelNames[ch]}" type="checkbox" data-channel-toggle="${ch}" ${state.channel[ch].enabled?'checked':''}></div>`).join('')}<p class="tiny muted">La captura real de notificaciones requiere instalar el proyecto Android y otorgar permiso al servicio de escucha.</p></div>
    <div class="card"><h2>Seguridad y privacidad</h2><div class="stack"><div class="between"><span class="small">Imágenes: confirmación manual</span><span class="pill">OBLIGATORIA</span></div><div class="between"><span class="small">Solo contactos autorizados</span><span class="pill ${state.settings.requireAllowlist?'':'off'}">${state.settings.requireAllowlist?'SÍ':'NO'}</span></div><div class="between"><span class="small">Grupos bloqueados</span><span class="pill ${state.settings.blockGroups?'':'off'}">${state.settings.blockGroups?'SÍ':'NO'}</span></div><div class="divider"></div><p class="small muted">No se envían conversaciones a servidores. Sin servicios de IA de pago.</p><button class="btn soft" data-go="ajustes">Revisar seguridad →</button></div></div></div>
    <div class="section"><div class="section-header"><h2 class="section-title">Asistentes listos para configurar</h2><button class="btn soft" data-go="asistentes">Administrar →</button></div><div class="grid cols3">${Object.entries(state.assistants).map(([id,detail])=>`<article class="card"><div class="between"><span class="circle">${id==='movieplay'?'🎬':id==='tresm'?'🍔':'🤖'}</span><span class="pill ${detail.active?'':'off'}">${detail.active?'Activo':'Pausado'}</span></div><h2 class="top-space">${labelFor(id)}</h2><p class="small muted">${id==='movieplay'?'Streaming, promociones y soporte':id==='tresm'?'Menú, pedidos y ubicación':'Mensajes de ausencia personalizables'}</p></article>`).join('')}</div></div>
    <div class="section"><div class="notice">💡 Primero autoriza un contacto de prueba y utiliza el <button class="btn mini" data-go="pruebas">Simulador</button>. Después puedes habilitar el autoenvío de texto en Android.</div></div>`;
  }
  function renderAutomation(){
    const rows=['normal','business'].map(ch=>{
      const enabled=!!state.channel[ch]?.enabled;
      const auto=!!state.settings.autoReplies[ch];
      const allowed=state.allowlist.filter(x=>x.channel===ch).length;
      return `<article class="card stack auto-channel"><div class="between"><div><h2>${safe(channelNames[ch])}</h2><p class="small muted">${safe(labelFor(state.channel[ch].assistant))} · ${allowed} contacto(s) de prueba</p></div><span class="pill ${auto?'':'off'}">${auto?'AUTO TEXTO ACTIVADO':'AUTO TEXTO APAGADO'}</span></div><label class="between"><span>Recibir notificaciones para revisión</span><input class="toggle" type="checkbox" data-channel-toggle="${ch}" ${enabled?'checked':''}></label><div class="divider"></div><label class="between"><span><strong>Responder texto automáticamente</strong><small class="muted small-note">Solo contactos autorizados · Sin imágenes automáticas</small></span><input class="toggle" type="checkbox" data-auto-reply="${ch}" ${auto?'checked':''} ${native?'':'disabled'}></label>${!native?'<p class="tiny muted">Para habilitar esta función, abre el APK Android.</p>':''}<p class="small muted">Máximo una respuesta por conversación cada 10 minutos. Si la notificación no permite respuesta directa, no se envía nada.</p></article>`;
    }).join('');
    return `<div class="home-intro"><div><span class="pill">CONTROL EXPERIMENTAL</span><h2>Automatización controlada, por WhatsApp.</h2><p class="small muted">La app prepara borradores para todos los contactos permitidos y solo responde automáticamente a quienes autorices explícitamente.</p></div><button class="btn danger" data-action="stop-auto">■ Detener todo autoenvío</button></div>
      <div class="grid cols2">${rows}</div>
      <div class="card stack top-space"><h2>Antes de activar</h2><p class="small muted">1. Autoriza un contacto de prueba con su nombre exacto de notificación y el canal. 2. Prueba la consulta en el simulador. 3. Da permiso de acceso a notificaciones desde Android. 4. Habilita autoenvío en ese WhatsApp.</p><div class="row"><button class="btn soft" data-go="contactos">Contactos autorizados →</button><button class="btn soft" data-go="pruebas">Simulador →</button><button class="btn soft" data-action="notification-settings" ${native?'':'disabled'}>Permiso Android →</button></div><div class="notice">⚠️ Este método utiliza respuestas de notificaciones, no una API autorizada de Meta. Puede fallar o exponer la cuenta a restricciones; WhatsApp no garantiza la entrega. No se automatizan imágenes ni grupos. La pausa cuando respondes tú es manual por ahora.</div></div>`;
  }
  function renderAssistants(){return `<div class="grid cols3">${Object.entries(state.assistants).map(([id,detail])=>`<article class="card stack"><div class="between"><span class="circle">${id==='movieplay'?'🎬':id==='tresm'?'🍔':'🤖'}</span><input type="checkbox" class="toggle" data-assistant-toggle="${id}" ${detail.active?'checked':''}></div><h2>${labelFor(id)}</h2><p class="small muted">${id==='movieplay'?'Atención sobre servicios y ventas de MoviePlay':id==='tresm'?'Consultas sobre comidas rápidas de Las Tres M':'Respuestas y mensajes de ausencia personalizados'}</p><span class="pill">${state.rules.filter(r=>r.assistant===id).length} reglas</span></article>`).join('')}</div><div class="section card"><h2>Asignación predeterminada</h2><p class="small muted">Recomendado: «Detectar negocio» en ambos canales. Ante una consulta ambigua se pide aclaración; los contactos con excepción tienen prioridad.</p><div class="grid cols2">${['normal','business'].map(ch=>`<div class="form-control"><label>${channelNames[ch]}</label><select data-channel-assistant="${ch}">${opts(state.channel[ch].assistant)}</select></div>`).join('')}</div><div class="notice top-space">Los asistentes no comparten reglas ni imágenes. Los contactos con excepciones siempre tienen prioridad sobre el asistente del canal.</div></div>`;}
  function renderContacts(){
    const lines=(arr,type)=>arr.length?arr.map(x=>`<div class="contact-line"><div class="contact-meta"><strong>${safe(x.contact||x.phone)}</strong>${x.phone&&x.phone!==x.contact?`<small>☎ ${safe(x.phone)}</small>`:''}<small>${channelNames[x.channel]} ${type==='exceptions'?' → '+labelFor(x.assistant):''}</small></div><button class="btn mini danger" data-delete-contact="${safe(type)}:${safe(x.id)}">Quitar</button></div>`).join(''):`<div class="empty">Sin contactos configurados.</div>`;
    return `<div class="split contacts-layout"><div class="stack"><div class="card"><h2>Excepciones por contacto</h2><p class="small muted">Asigna un asistente concreto al contacto, sin afectar otras conversaciones.</p>${lines(state.exceptions,'exceptions')}</div><div class="card"><h2>Lista de pruebas autorizadas</h2><p class="small muted">Solo los contactos autorizados pueden recibir auto-respuestas si activas esta opción.</p>${lines(state.allowlist,'allowlist')}</div><div class="card"><h2>Contactos excluidos</h2>${lines(state.blocked,'blocked')}</div><div class="card"><h2>Pausas manuales</h2><p class="small muted">Se reactivan después de una hora.</p>${lines((state.paused||[]).filter(x=>x.until>Date.now()),'paused')}</div></div>
    <div class="card contact-editor"><h2>Agregar contacto</h2><p class="small muted">Puedes escribir el número, el nombre que muestra WhatsApp o elegir un contacto de tu teléfono. No es obligatorio seleccionar uno del directorio.</p>
      <div class="stack">
        ${native?'<button class="btn contact-picker" data-action="pick-contact" type="button">♧ Elegir de mis contactos Android</button>':'<div class="notice">El selector del teléfono está disponible en la APK Android. Aquí puedes escribir el número manualmente.</div>'}
        <div class="form-control"><label for="ctPhone">Número de WhatsApp</label><input class="field" id="ctPhone" type="tel" inputmode="tel" autocomplete="off" placeholder="Ej. 300 123 4567 o +57 300…"><small class="muted">Escribe el número y guárdalo directamente. No necesitas tocar el selector.</small></div>
        <div class="form-control"><label for="ctName">Nombre visible en WhatsApp (opcional)</label><input class="field" id="ctName" placeholder="Ej. Carlos Bedoya" autocomplete="off"><small class="muted">Si WhatsApp notifica con el nombre guardado, añádelo aquí o elígelo del directorio para identificarlo correctamente.</small></div>
        <div class="form-control"><label for="ctChannel">WhatsApp donde escribe</label><select id="ctChannel"><option value="normal">WhatsApp normal</option><option value="business">WhatsApp Business</option></select></div>
        <div class="form-control"><label for="ctType">Qué hará el asistente</label><select id="ctType"><option value="allowlist">Autorizar para pruebas</option><option value="exceptions">Asignar asistente</option><option value="blocked">No responder</option><option value="paused">Pausar durante una hora</option></select></div>
        <div class="form-control" id="ctAssistantRow" hidden><label for="ctAssistant">Asistente para este contacto</label><select id="ctAssistant">${opts('movieplay')}</select></div>
        <button class="btn primary" data-action="add-contact" type="button">Guardar contacto</button>
        <div class="notice">Por seguridad, el texto automático sigue apagado inicialmente y solo responde a contactos autorizados en el WhatsApp elegido.</div>
      </div>
    </div></div>`;
  }
  function renderRules(){return `<div class="section-header"><p class="small muted">Una regla contiene palabras clave, un mensaje aprobado y una etiqueta opcional de imagen.</p><button class="btn primary" data-action="new-rule">+ Nueva regla</button></div><div class="stack">${state.rules.map(r=>`<article class="card"><div class="between"><div><span class="pill">${labelFor(r.assistant)}</span><h2 class="top-space">${safe(short(r.keywords,100))}</h2></div><input class="toggle" type="checkbox" aria-label="Activar regla" data-rule-toggle="${safe(r.id)}" ${r.active?'checked':''}></div><p class="small muted" style="white-space:pre-wrap">${safe(short(r.response,220))}${r.response.length>220?'…':''}</p><div class="meta-line"><span class="chip">Imagen: ${safe(r.imageTag||'ninguna')}</span></div><div class="row"><button class="btn mini soft" data-edit-rule="${safe(r.id)}">Editar</button><button class="btn mini danger" data-delete-rule="${safe(r.id)}">Eliminar</button></div></article>`).join('')}</div>`;}
  function renderRuleEditor(id){const r=state.rules.find(x=>x.id===id)||{id:'',assistant:'movieplay',keywords:'',response:'',imageTag:'',active:true}; return `<div class="section-header"><h2 class="section-title">${r.id?'Editar regla':'Nueva regla'}</h2><button class="btn soft" data-action="cancel-rule">Volver</button></div><div class="card stack"><div class="form-control"><label>Asistente</label><select id="ruleAssistant">${opts(r.assistant).replace(/<option value="none"[^>]*>.*?<\/option>/,'')}</select></div><div class="form-control"><label>Palabras o frases clave, separadas por comas</label><input class="field" id="ruleKeywords" value="${safe(r.keywords)}" placeholder="Ej: netflix, precios netflix"></div><div class="form-control"><label>Respuesta oficial</label><textarea id="ruleResponse" rows="6">${safe(r.response)}</textarea></div><div class="form-control"><label>Etiqueta de la imagen (opcional)</label><input class="field" id="ruleImage" value="${safe(r.imageTag)}" placeholder="Ej: netflix"></div><div class="notice">El motor inicial detecta palabras clave y genera borradores. La IA generativa aún no está incluida: evita inventar precios o garantías.</div><button class="btn primary" data-save-rule="${safe(r.id)}">Guardar regla</button></div>`;}
  function renderImages(){return `<div class="section-header"><p class="small muted">Publicidad local para sugerencias y envío manual desde Android.</p><button class="btn primary" data-action="add-image">+ Agregar imagen</button></div>
  <div class="grid cols3">${state.images.length ?state.images.map(i=>`<article class="card image-card"><div class="image-preview" data-thumb="${safe(i.id)}"><span class="image-placeholder">▧</span></div><div class="image-body"><div class="between"><h3>${safe(i.title)}</h3><span class="pill ${i.active?'':'off'}">${i.active?'Activa':'Inactiva'}</span></div><p>${labelFor(i.assistant)} · ${safe(i.tags)}</p><p class="tiny muted">${!isImageValid(i)?'No vigente':i.validUntil?'Disponible hasta '+safe(i.validUntil):'Sin vencimiento configurado'}</p><div class="actions"><button class="btn mini" data-share-image="${safe(i.id)}">Revisar envío</button><button class="btn mini soft" data-image-toggle="${safe(i.id)}">${i.active?'Pausar':'Activar'}</button><button class="btn mini danger" data-delete-image="${safe(i.id)}">Eliminar</button></div></div></article>`).join(''):`<div class="empty">Todavía no hay imágenes. Agrega publicidad de MoviePlay o el menú de Las Tres M.</div>`}</div>
  <div class="notice top-space">ℹ️ Las imágenes se guardan localmente en el navegador (IndexedDB). En Android se envían al selector de compartir como archivo, pero el envío final debe confirmarse dentro de WhatsApp. No hay sincronización automática con el panel del otro dispositivo.</div>`;}
  function renderInbox(){return `<div class="section-header"><p class="small muted">La app prepara respuestas e imágenes. Si activas autoenvío, enviará solo textos con regla aprobada a contactos autorizados; las imágenes siempre se revisan.</p><button class="btn soft" data-action="refresh-inbox">↻ Actualizar</button></div><div class="stack">${state.inbox.length?state.inbox.map(i=>{const r=respond(i.channel,i.contact,i.text,!!i.group);return `<div class="card"><div class="between"><strong class="small">${safe(i.contact)}</strong><span class="pill">${safe(channelNames[i.channel]||i.channel)}</span></div><p class="message top-space">${safe(short(i.text,350))}</p>${r.assistant?`<div class="meta-line"><span class="chip">${safe(labelFor(r.assistant))}</span>${r.unit?`<span class="chip">${safe(departmentName(r.assistant,r.unit))}</span>`:''}${r.status==='closed'?'<span class="chip warning">Fuera de horario</span>':''}</div>`:''}<p class="tiny muted">${new Date(i.time||Date.now()).toLocaleString('es-CO')} ${i.attempted?' · Compartir abierto para revisión (sin confirmar envío)':''}${i.autoStatus==='submitted_unverified'?' · Respuesta enviada a Android (sin confirmar entrega)':i.autoStatus==='throttled'?' · Autoenvío limitado por seguridad':i.autoStatus==='no_quick_reply'?' · WhatsApp no ofreció respuesta directa':i.autoStatus?.startsWith('failed')?' · Error al intentar responder':''}</p>${r.reason?`<div class="notice">${safe(r.reason)}</div>`:`<div class="reply" style="margin:12px 0;white-space:pre-wrap">${safe(short(r.reply,400))}</div>${r.image?`<div class="notice">🖼 Imagen seleccionada: <strong>${safe(r.image.title)}</strong> · ${safe(r.image.validUntil?'Hasta '+r.image.validUntil:'Sin vencimiento')}</div>`:'<p class="tiny muted">No hay imagen vigente vinculada a esta regla.</p>'}`}<div class="row">${r.image?`<button class="btn primary mini" data-review-inbox="${safe(i.id)}">Revisar imagen</button>`:''}<button class="btn soft mini" data-use-inbox="${safe(i.id)}">Abrir respuesta</button>${!authorized(i.channel,i.contact)?`<button class="btn mini soft" data-allow-inbox="${safe(i.id)}">Autorizar pruebas</button>`:''}<button class="btn mini soft" data-pause-inbox="${safe(i.id)}">Pausar 1 h</button><button class="btn danger mini" data-delete-inbox="${safe(i.id)}">Quitar</button></div></div>`;}).join(''):'<div class="empty">No hay mensajes pendientes. En el navegador web, esta bandeja estará vacía hasta que Android capture notificaciones permitidas.</div>'}</div>`;}
  function renderTests(){const ct = runtime.selectedInbox?state.inbox.find(i=>i.id===runtime.selectedInbox):null;return `<div class="split"><div class="card stack"><h2>Simular una pregunta</h2><p class="small muted">Prueba la selección de asistente y respuesta sin enviar mensajes.</p><div class="form-control"><label>Canal</label><select id="testChannel"><option value="business" ${ct?.channel!=='normal'?'selected':''}>WhatsApp Business</option><option value="normal" ${ct?.channel==='normal'?'selected':''}>WhatsApp normal</option></select></div><div class="form-control"><label>Contacto (coincidencia exacta)</label><input id="testContact" class="field" value="${safe(ct?.contact||'Cliente de prueba')}" placeholder="Cliente de prueba"></div><div class="form-control"><label>Mensaje entrante</label><textarea id="testMessage" rows="4">${safe(ct?.text||'Hola, ¿qué precio tiene Netflix?')}</textarea></div><div class="form-control"><label>Fecha y hora de prueba (Bogotá)</label><input type="datetime-local" class="field" id="testDate" value="${SE.bogotaParts().date}T${SE.bogotaParts().time}"></div><div class="notice">Prueba Netflix, hamburguesa, horario sin indicar negocio o soporte de MoviePlay un domingo a las 6:00 p. m.</div><div class="between"><label class="small muted"><input type="checkbox" id="testGroup"> Es un grupo</label><button class="btn primary" data-action="simulate">Generar sugerencia →</button></div></div><div class="card stack" id="resultArea"><h2>Respuesta sugerida</h2><div class="empty">Completa la prueba y pulsa «Generar sugerencia».</div></div></div>`;}
  function renderSettings(){return `<div class="grid cols2"><div class="card stack"><h2>Seguridad</h2><label class="between small"><span>Exigir contacto autorizado</span><input class="toggle" type="checkbox" data-setting="requireAllowlist" ${state.settings.requireAllowlist?'checked':''}></label><label class="between small"><span>Excluir notificaciones de grupos</span><input class="toggle" type="checkbox" data-setting="blockGroups" ${state.settings.blockGroups?'checked':''}></label><div class="notice">Imágenes siempre con confirmación manual. El texto puede enviarse solo a contactos autorizados mediante activación expresa por WhatsApp. No hay mensajes masivos.</div></div><div class="card stack"><h2>Conexión Android</h2><p class="small muted" id="androidStatus">${native?'La aplicación Android está disponible.':'Abierto como panel web (modo sin Android).'}</p><button class="btn soft" data-action="notification-settings" ${native?'':'disabled'}>Abrir permiso de notificaciones</button><p class="tiny muted">El acceso a notificaciones permite leer avisos y, si tú activas Auto Texto por canal, usar la acción de respuesta directa cuando exista.</p><button class="btn primary" data-go="automatizacion">Configurar autoenvío de texto →</button></div><div class="card stack"><h2>Respaldos y transferencias</h2><p class="small muted">El respaldo contiene asistentes, reglas, asignaciones y datos de imágenes, pero no los archivos originales de imagen.</p><button class="btn" data-action="export">Exportar configuración JSON</button><button class="btn soft" data-action="import">Importar archivo JSON</button><button class="btn soft" data-action="copy-config">Copiar configuración</button><div class="form-control"><label>O pega aquí un respaldo JSON</label><textarea id="jsonImport" rows="3" placeholder="Pega el JSON de configuración"></textarea></div><button class="btn soft" data-action="paste-import">Importar texto</button></div><div class="card stack"><h2>Limitaciones actuales</h2><p class="small muted">No hay servidor, cuentas de usuario ni sincronización en tiempo real. El panel puede abrirse en una computadora y en Android, pero cada instalación guarda sus propias configuraciones hasta importar un respaldo.</p><p class="small muted">El motor incluido es determinista (palabras clave y reglas), no IA generativa. Puede añadirse un modelo local posteriormente según la capacidad del dispositivo.</p><button class="btn danger" data-action="reset">Restablecer configuración local</button></div></div>`;}
  function closeReview(){runtime.review=null;const modal=$('#reviewModal');if(modal)modal.remove();}
  function openReview(info){
    closeReview();runtime.review=info;
    const item=state.images.find(i=>i.id===info.imageId);if(!item)return notify('Imagen no encontrada.');
    const modal=el('div',{id:'reviewModal',className:'review-overlay'});
    modal.innerHTML=`<div class="review-dialog" role="dialog" aria-modal="true" aria-label="Revisión del envío de imagen"><div class="between"><h2>Revisar publicidad</h2><button class="btn mini soft" data-action="close-review">Cerrar ✕</button></div><div class="review-body"><div class="review-preview" id="reviewPreview">Preparando vista previa…</div><div class="stack"><p class="small muted">Contacto esperado: <strong>${safe(info.contact||'Sin contacto')}</strong></p><div class="form-control"><label>Aplicación para compartir</label><select id="reviewChannel"><option value="normal" ${info.channel==='normal'?'selected':''}>WhatsApp normal</option><option value="business" ${info.channel==='business'?'selected':''}>WhatsApp Business</option></select></div><div class="form-control"><label>Mensaje que acompañará la imagen</label><textarea id="reviewCaption" rows="5">${safe(info.caption||'')}</textarea></div><label class="checkline"><input type="checkbox" id="reviewChecked"> Entiendo que debo verificar el destinatario en WhatsApp y pulsar enviar personalmente.</label><div class="notice">La imagen se abrirá en WhatsApp para revisión. No se ha enviado nada.</div><button class="btn primary" data-action="confirm-review">Abrir WhatsApp para revisar →</button></div></div></div>`;
    document.body.appendChild(modal);
    getImageUrl(info.imageId).then(url=>{const node=$('#reviewPreview');if(node&&url)node.innerHTML=`<img alt="${safe(item.title)}" src="${safe(url)}">`;else if(node)node.textContent='Imagen no disponible en este dispositivo.';});
  }
  function render(){const h=({inicio:renderHome,automatizacion:renderAutomation,horarios:renderSchedules,asistentes:renderAssistants,contactos:renderContacts,reglas:renderRules,imagenes:renderImages,bandeja:renderInbox,pruebas:renderTests,ajustes:renderSettings})[runtime.route];$('#screen').innerHTML=h();$('#inboxCount').textContent=state.inbox.length;if(runtime.route==='imagenes')state.images.forEach(async m=>{const url=await getImageUrl(m.id);const preview=document.querySelector(`[data-thumb="${m.id}"]`);if(preview&&url){preview.innerHTML='';const img=el('img',{src:url,alt:m.title});preview.appendChild(img);}});if(runtime.route==='bandeja')document.querySelectorAll('[data-inbox-thumb]').forEach(async node=>{const url=await getImageUrl(node.dataset.inboxThumb);if(url){const img=el('img',{src:url,alt:'Publicidad sugerida'});node.appendChild(img);}});}
  function switchResult(r){const area=$('#resultArea');if(!area)return;runtime.testReply=null;runtime.testImage=null;if(r.reason){area.innerHTML=`<h2>No se genera respuesta</h2><div class="notice danger-note">${safe(r.reason)}</div><p class="small muted">Revisa canal, autorización, excepciones o reglas.</p>`;return;} runtime.testReply=r.reply;runtime.testImage=r.image?.id||null;area.innerHTML=`<div class="between"><h2>Respuesta sugerida</h2><span class="pill">${labelFor(r.assistant)}</span></div>${r.requiresSelection?'<div class="notice">⚠️ Se necesita confirmar el negocio. No se seleccionan horarios de forma automática.</div>':''}${r.unit?`<div class="meta-line"><span class="chip">${safe(departmentName(r.assistant,r.unit))}</span><span class="chip">${r.status==='closed'?'Fuera de horario · ':''}${safe(r.schedule?.label||'')}</span></div>`:''}<div class="reply">${safe(r.reply)}</div>${r.image?`<div class="result"><div class="thumb" data-test-thumb="${safe(r.image.id)}"></div><div class="small"><strong>${safe(r.image.title)}</strong><div class="muted tiny">Imagen coincidente para revisión</div></div></div>`:''}<div class="row"><button class="btn primary" data-action="share-test-text">Revisar texto en WhatsApp</button>${r.image?'<button class="btn soft" data-action="share-test-image">Revisar imagen</button>':''}</div><div class="tiny muted">En WhatsApp tú eliges o verificas el destinatario y confirmas el envío. La app no marca el mensaje como enviado.</div>`;if(r.image)getImageUrl(r.image.id).then(url=>{const p=$('[data-test-thumb]');if(p&&url){const i=el('img',{src:url,className:'thumb',alt:r.image.title});p.replaceWith(i);}});}
  // IndexedDB stores images as Blobs, never in configuration JSON.
  const DB='arpro_media_v1';let dbPromise=null;
  function db(){if(!dbPromise)dbPromise=new Promise((resolve,reject)=>{const request=indexedDB.open(DB,1);request.onupgradeneeded=()=>{request.result.createObjectStore('images');};request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});return dbPromise;}
  async function putImage(id,blob){const d=await db();return new Promise((resolve,reject)=>{const tr=d.transaction('images','readwrite');tr.objectStore('images').put(blob,id);tr.oncomplete=resolve;tr.onerror=()=>reject(tr.error);});}
  async function getImage(id){const d=await db();return new Promise((resolve,reject)=>{const request=d.transaction('images','readonly').objectStore('images').get(id);request.onsuccess=()=>resolve(request.result||null);request.onerror=()=>reject(request.error);});}
  async function deleteImage(id){const d=await db();return new Promise((resolve,reject)=>{const tr=d.transaction('images','readwrite');tr.objectStore('images').delete(id);tr.oncomplete=resolve;tr.onerror=()=>reject(tr.error);});}
  const imageUrls=new Map();async function getImageUrl(id){if(imageUrls.has(id))return imageUrls.get(id);const b=await getImage(id);if(!b)return null;const url=URL.createObjectURL(b);imageUrls.set(id,url);return url;}
  function closeImageEditor(){
    if(runtime.pendingImage?.url)URL.revokeObjectURL(runtime.pendingImage.url);
    runtime.pendingImage=null;
    $('#imageEditModal')?.remove();
  }
  function openImageEditor(file){
    closeImageEditor();
    const url=URL.createObjectURL(file);
    runtime.pendingImage={file,url};
    const suggestedTag=normalize(file.name).match(/netflix|disney|prime|hamburguesa|menu|horario|patacon|combo|soporte/)?.[0]||'';
    const modal=el('div',{id:'imageEditModal',className:'review-overlay'});
    modal.innerHTML=`<div class="review-dialog" role="dialog" aria-modal="true" aria-label="Añadir publicidad">
      <div class="between"><div><h2>Nueva imagen de publicidad</h2><p class="small muted">Define a qué negocio pertenece y cuándo puede sugerirse.</p></div><button class="btn soft mini" data-action="cancel-image">Cerrar ✕</button></div>
      <div class="review-body"><div class="review-preview"><img src="${safe(url)}" alt="Vista previa de publicidad"></div><div class="stack">
        <div class="form-control"><label>Nombre de la publicidad</label><input class="field" id="newImageTitle" maxlength="80" value="${safe(file.name.replace(/\.[^.]+$/,''))}"></div>
        <div class="form-control"><label>Negocio</label><select id="newImageAssistant"><option value="movieplay">🎬 MoviePlay</option><option value="tresm">🍔 Las Tres M</option><option value="personal">🤖 Personalizado</option></select></div>
        <div class="form-control"><label>Palabras clave para seleccionarla (separadas por comas)</label><input class="field" id="newImageTags" value="${safe(suggestedTag)}" placeholder="Ej. netflix, combos, promociones"></div>
        <div class="grid cols2"><div class="form-control"><label>Desde (opcional)</label><input type="date" class="field" id="newImageFrom"></div><div class="form-control"><label>Hasta (opcional)</label><input type="date" class="field" id="newImageUntil"></div></div>
        <div class="notice">Esta imagen solo será sugerida para el negocio seleccionado y durante su vigencia. El envío siempre se confirma dentro de WhatsApp.</div>
        <button class="btn primary" data-action="save-image">Guardar publicidad</button>
      </div></div></div>`;
    document.body.appendChild(modal);
  }
  async function addImageFile(file){
    if(!file)return;
    if(!['image/jpeg','image/png','image/webp'].includes(file.type))return notify('Formato permitido: JPG, PNG o WebP.');
    if(file.size>4*1024*1024)return notify('Máximo 4 MB por imagen.');
    openImageEditor(file);
  }
  async function shareImageById(id,channel='business',caption=''){const blob=await getImage(id);if(!blob){notify('Archivo no encontrado en este dispositivo. Impórtalo nuevamente.');return false;}if(native){try{const encoded=await blobToBase64(blob);if(encoded.length>6_000_000){notify('La imagen es demasiado grande para compartir. Redúcela a menos de 4 MB.');return false;}window.AndroidBridge.shareImage(encoded,blob.type||'image/jpeg',caption,channel);notify('Abriendo WhatsApp para tu revisión; el envío no está confirmado.');return true;}catch(e){notify('Error preparando la imagen: '+e.message);return false;}}if(navigator.share && navigator.canShare){const file=new File([blob],'publicidad.'+(blob.type==='image/png'?'png':'jpg'),{type:blob.type});try{if(navigator.canShare({files:[file]})){await navigator.share({files:[file],text:caption});return true;}}catch(e){if(e.name==='AbortError')return false;}}
    const url=URL.createObjectURL(blob);const a=el('a',{href:url,download:'publicidad.jpg'});a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);notify('Imagen descargada. Puedes adjuntarla manualmente en WhatsApp.');return true;}
  const blobToBase64=(blob)=>new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=()=>reject(reader.error);reader.readAsDataURL(blob);});
  function shareText(text,channel){if(native){window.AndroidBridge.shareText(text,channel);notify('Revisa destinatario y envía desde WhatsApp.');return;}if(navigator.share){navigator.share({text}).catch(()=>navigator.clipboard?.writeText(text));return;}navigator.clipboard?.writeText(text).then(()=>notify('Texto copiado. Pégalo en WhatsApp.'),()=>notify('Copia el texto manualmente.'));}
  function syncNativeCapture(){
    if(!native)return;
    try{
      if(typeof window.AndroidBridge.setCaptureChannels==='function')window.AndroidBridge.setCaptureChannels(!!state.channel.normal?.enabled,!!state.channel.business?.enabled);
      // Native listener needs the SAME policy, rules and schedules shown in this panel.
      // Never copy message inbox, media, passwords or any network tokens.
      if(typeof window.AndroidBridge.syncAutomationConfig==='function'){
        const {channel,assistants,exceptions,allowlist,blocked,paused,rules,schedules,scheduleOverrides,settings}=state;
        window.AndroidBridge.syncAutomationConfig(JSON.stringify({version:1,channel,assistants,exceptions,allowlist,blocked,paused,rules,schedules,scheduleOverrides,settings}));
      }
    }catch(e){console.warn('Error sincronizando Android',e);}
  }
  async function loadNative(){if(!native)return;try{const json=window.AndroidBridge.getInbox();const incoming=JSON.parse(json);if(Array.isArray(incoming)){for(const n of incoming.slice(0,40)){if(!state.inbox.some(x=>x.id===n.id))state.inbox.unshift(n);}state.inbox=state.inbox.slice(0,40);save(); if (typeof window.AndroidBridge.clearInbox === 'function')window.AndroidBridge.clearInbox();}}catch(e){console.warn('No se puede leer la bandeja:',e);}}
  // Receives ONLY the contact explicitly chosen through Android ACTION_PICK.
  window.onAndroidContactSelected=(selection)=>{
    if(runtime.route!=='contactos')return;
    let result;
    try{result=typeof selection==='string'?JSON.parse(selection):selection;}catch(_){return notify('No fue posible leer el contacto.');}
    const phone=String(result?.phone||'').trim();
    const name=String(result?.name||'').trim();
    if (!phoneKey(phone))return notify('El contacto elegido no tiene un número válido.');
    if($('#ctPhone'))$('#ctPhone').value=phone;
    if($('#ctName'))$('#ctName').value=name;
    notify('Contacto seleccionado. Revisa el WhatsApp y pulsa Guardar.');
  };
  // Global delegated interactions.
  document.addEventListener('change',e=>{
    if(e.target?.id==='ctType'){
      const row=$('#ctAssistantRow');if(row)row.hidden=e.target.value!=='exceptions';
    }
  });
  document.addEventListener('click',async e=>{
    const button=e.target.closest('button');if(!button)return;
    if(button.dataset.route){setRoute(button.dataset.route);return;}
    if(button.dataset.go){setRoute(button.dataset.go);return;}
    if(button.id==='menuButton'){$('.sidebar').classList.toggle('open');return;}
    const a=button.dataset.action;
    if(a==='stop-auto'){
      state.settings.autoReplies={normal:false,business:false};save();render();notify('Autoenvíos detenidos en ambos WhatsApp.');return;
    }
    if(button.dataset.allowInbox){
      const msg=state.inbox.find(i=>i.id===button.dataset.allowInbox);
      if(msg && !authorized(msg.channel,msg.contact)){
        if(!confirm('Autorizar a '+msg.contact+' para PRUEBAS en '+channelNames[msg.channel]+'? El envío automático seguirá apagado hasta activarlo por separado.'))return;
        state.allowlist.push({id:token(),contact:msg.contact,channel:msg.channel});
        save();render();notify('Contacto autorizado para pruebas en '+channelNames[msg.channel]);
      }return;
    }
    if(button.dataset.pauseInbox){
      const msg=state.inbox.find(i=>i.id===button.dataset.pauseInbox);
      if(msg){
        const existing=state.paused.find(x=>x.channel===msg.channel&&sameContact(x,msg.contact));
        if(existing)existing.until=Date.now()+60*60*1000;
        else state.paused.push({id:token(),channel:msg.channel,contact:msg.contact,until:Date.now()+60*60*1000});
        save();render();notify('Pausa manual de 1 hora para '+msg.contact);
      }return;
    }
    if(a==='use-mixed'){
      state.channel.normal.assistant='auto';state.channel.business.assistant='auto';save();render();notify('Detección de negocio activada para ambos canales (sin enviar mensajes).');return;
    }
    if(a==='save-override'){
      const [assistant,unit]=$('#ovUnit').value.split(':');const date=$('#ovDate').value,mode=$('#ovMode').value;
      const start=$('#ovStart').value,end=$('#ovEnd').value;
      if(!/^\d{4}-\d{2}-\d{2}$/.test(date) || SE.bogotaParts(SE.parseBogotaLocal(date+'T12:00')).date!==date)return notify('La fecha indicada no es válida.');
      if(mode==='hours'&&!SE.validRange(start,end))return notify('La hora de apertura debe ser anterior al cierre.');
      const note=$('#ovNote').value.trim();
      state.scheduleOverrides=state.scheduleOverrides.filter(x=>!(x.assistant===assistant&&x.unit===unit&&x.date===date));
      state.scheduleOverrides.push({id:token(),assistant,unit,date,mode,start:mode==='hours'?start:'',end:mode==='hours'?end:'',note});
      save();render();notify('Excepción guardada solo para el área elegida.');return;
    }
    if(button.dataset.deleteOverride){state.scheduleOverrides=state.scheduleOverrides.filter(x=>x.id!==button.dataset.deleteOverride);save();render();notify('Excepción eliminada.');return;}
    if(a==='pick-contact'){
      if(!native || typeof window.AndroidBridge.pickPhoneContact!=='function')return notify('El selector de contactos requiere la APK 0.5.1.');
      try{window.AndroidBridge.pickPhoneContact();}catch(_){notify('No se pudo abrir la agenda. Puedes escribir el número.');}
      return;
    }
    if(a==='add-contact'){
      const contactName=($('#ctName')?.value||'').trim();
      const rawPhone=($('#ctPhone')?.value||'').trim();
      const phone=phoneKey(rawPhone);
      if(rawPhone&&!phone)return notify('Revisa el número: debe tener entre 7 y 15 dígitos.');
      if(!contactName&&!phone)return notify('Escribe un número o un nombre visible en WhatsApp.');
      const contact=contactName||phone;
      const channel=$('#ctChannel').value,type=$('#ctType').value,assistant=$('#ctAssistant').value;
      const list=state[type];if(!Array.isArray(list))return;
      const until=type==='paused'?Date.now()+60*60*1000:undefined;
      const exists=list.find(x=>x.channel===channel&&(sameContact(x,contact)||(phone&&sameContact(x,phone))));
      if(exists){exists.contact=contact;exists.phone=phone;exists.assistant=assistant;if(until)exists.until=until;}
      else list.push({id:token(),contact,phone,channel,assistant,until});
      save();render();notify('Contacto guardado en '+channelNames[channel]+'.');return;
    }
    if(button.dataset.deleteContact){const [type,id]=button.dataset.deleteContact.split(':');state[type]=state[type].filter(x=>x.id!==id);save();render();return;}
    if(a==='new-rule'){runtime.route='rule-edit';$('#screen').innerHTML=renderRuleEditor('');return;}
    if(button.dataset.editRule!==undefined){runtime.route='rule-edit';$('#screen').innerHTML=renderRuleEditor(button.dataset.editRule);return;}
    if(a==='cancel-rule'){setRoute('reglas');return;}
    if(button.dataset.saveRule!==undefined){const id=button.dataset.saveRule;const r={id:id||token(),assistant:$('#ruleAssistant').value,keywords:$('#ruleKeywords').value.trim(),response:$('#ruleResponse').value.trim(),imageTag:$('#ruleImage').value.trim(),active:true};if(!r.keywords||!r.response)return notify('La regla necesita palabras clave y respuesta.');if(id){const p=state.rules.findIndex(x=>x.id===id);if(p>=0){r.active=state.rules[p].active;state.rules[p]=r;}}else state.rules.push(r);save();setRoute('reglas');notify('Regla guardada.');return;}
    if(button.dataset.deleteRule){if(confirm('¿Eliminar esta regla?')){state.rules=state.rules.filter(x=>x.id!==button.dataset.deleteRule);save();render();}return;}
    if(a==='cancel-image'){closeImageEditor();return;}
    if(a==='save-image'){
      const file=runtime.pendingImage?.file;if(!file)return notify('Selecciona un archivo.');
      const title=$('#newImageTitle').value.trim(),assistant=$('#newImageAssistant').value;
      const tags=$('#newImageTags').value.trim(),from=$('#newImageFrom').value,until=$('#newImageUntil').value;
      if(!title||!tags)return notify('Agrega un nombre y al menos una palabra clave.');
      if(!state.assistants[assistant])return notify('Selecciona un negocio válido.');
      if((from && !/^\d{4}-\d{2}-\d{2}$/.test(from))||(until&&!/^\d{4}-\d{2}-\d{2}$/.test(until))||(from&&until&&from>until))return notify('Revisa la vigencia.');
      const id=token();
      try{await putImage(id,file);state.images.push({id,title,assistant,tags,active:true,type:file.type,validFrom:from,validUntil:until,createdAt:Date.now()});save();closeImageEditor();render();notify('Publicidad guardada.');}
      catch(e){notify('No se pudo guardar la imagen: '+e.message);}return;
    }
    if(a==='add-image'){$('#imageFile').click();return;}
    if(button.dataset.deleteImage){if(confirm('¿Eliminar esta imagen del dispositivo?')){await deleteImage(button.dataset.deleteImage);state.images=state.images.filter(i=>i.id!==button.dataset.deleteImage);save();render();}return;}
    if(button.dataset.imageToggle){const img=state.images.find(x=>x.id===button.dataset.imageToggle);if(img){img.active=!img.active;save();render();}return;}
    if(button.dataset.shareImage){openReview({imageId:button.dataset.shareImage,contact:'Seleccionar manualmente en WhatsApp',channel:'business',caption:'',inboxId:null,showChannel:true});return;}
    if(a==='refresh-inbox'){await loadNative();render();notify('Bandeja actualizada.');return;}
    if(button.dataset.useInbox){const msg=state.inbox.find(i=>i.id===button.dataset.useInbox);if(msg){runtime.selectedInbox=msg.id;setRoute('pruebas');switchResult(respond(msg.channel,msg.contact,msg.text,!!msg.group));}return;}
    if(button.dataset.reviewInbox){const msg=state.inbox.find(i=>i.id===button.dataset.reviewInbox);if(msg){const result=respond(msg.channel,msg.contact,msg.text,!!msg.group);if(result.image)openReview({imageId:result.image.id,contact:msg.contact,channel:msg.channel,caption:result.reply,inboxId:msg.id,showChannel:false});}return;}
    if(button.dataset.deleteInbox){state.inbox=state.inbox.filter(i=>i.id!==button.dataset.deleteInbox);save();render();return;}
    if(a==='simulate'){runtime.selectedInbox=null;const channel=$('#testChannel').value,contact=$('#testContact').value,msg=$('#testMessage').value,group=$('#testGroup').checked;let at;try{at=SE.parseBogotaLocal($('#testDate').value);}catch(e){return notify('Revisa la fecha y hora de Bogotá.');}switchResult(respond(channel,contact,msg,group,at));return;}
    if(a==='share-test-text' && runtime.testReply){shareText(runtime.testReply,$('#testChannel').value);return;}
    if(a==='share-test-image' && runtime.testImage){openReview({imageId:runtime.testImage,channel:$('#testChannel').value,contact:$('#testContact').value,caption:runtime.testReply||'',inboxId:runtime.selectedInbox});return;}
    if(a==='close-review'){closeReview();return;}
    if(a==='confirm-review'){if(!$('#reviewChecked')?.checked)return notify('Marca la comprobación de destinatario.');const info=runtime.review;if(!info)return;const caption=$('#reviewCaption').value,channel=$('#reviewChannel').value;const prepared=await shareImageById(info.imageId,channel,caption);if(prepared && info.inboxId){const msg=state.inbox.find(i=>i.id===info.inboxId);if(msg){msg.attempted=Date.now();save();}}closeReview();render();return;}
    if(a==='notification-settings'){if(native)window.AndroidBridge.openNotificationSettings();return;}
    if(a==='export'){const data=new Blob([JSON.stringify({...state,inbox:[]},null,2)],{type:'application/json'});const url=URL.createObjectURL(data);const link=el('a',{href:url,download:'autoresponder-pro-config.json'});link.click();setTimeout(()=>URL.revokeObjectURL(url),1500);notify('Respaldo de configuración generado.');return;}
    if(a==='import'){$('#configFile').click();return;}
    if(a==='copy-config'){navigator.clipboard?.writeText(JSON.stringify({...state,inbox:[]},null,2)).then(()=>notify('Configuración copiada.'),()=>notify('No se pudo copiar automáticamente.'));return;}
    if(a==='paste-import'){applyImport($('#jsonImport').value);return;}
    if(a==='reset'){if(confirm('¿Restablecer reglas y contactos? Las imágenes guardadas no se borrarán, pero dejarán de aparecer.')){state=defaults();save();render();notify('Configuración restablecida.');}return;}
  });
  document.addEventListener('toggle',e=>{if(e.target?.dataset?.scheduleDetails){const key=e.target.dataset.scheduleDetails;if(e.target.open)runtime.openSchedules.add(key);else runtime.openSchedules.delete(key);}},true);
  document.addEventListener('change',e=>{
    const t=e.target;
    if(t.id==='ovMode'){const area=$('#ovTimes');if(area)area.hidden=t.value!=='hours';return;}
    if(t.dataset.dayEnabled){
      const [assistant,unit,d]=t.dataset.dayEnabled.split(':');const rule=state.schedules[assistant]?.[unit]?.days[d];
      if(rule){rule.enabled=t.checked;save();render();notify('Día actualizado en '+departmentName(assistant,unit));}return;
    }
    if(t.dataset.dayStart||t.dataset.dayEnd){
      const [assistant,unit,d]=(t.dataset.dayStart||t.dataset.dayEnd).split(':');
      const row=state.schedules[assistant]?.[unit]?.days[d];if(!row)return;
      const start=t.dataset.dayStart?t.value:row.start,end=t.dataset.dayEnd?t.value:row.end;
      if(!SE.validRange(start,end)){notify('Horario incorrecto: apertura debe ser anterior al cierre.');render();return;}
      row.start=start;row.end=end;save();render();notify('Horario actualizado en '+departmentName(assistant,unit));return;
    }
    if(t.dataset.holidayMode){const [assistant,unit]=t.dataset.holidayMode.split(':');state.schedules[assistant][unit].holidayMode=t.checked?'sunday':'normal';save();render();notify('Regla de festivos actualizada.');return;}
    if(t.dataset.away){const [assistant,unit]=t.dataset.away.split(':');const val=t.value.trim();if(!val)return notify('El mensaje no puede estar vacío.');state.schedules[assistant][unit].away=val;save();notify('Mensaje de ausencia guardado.');return;}
    if(t.dataset.autoReply){
      const ch=t.dataset.autoReply;
      if(!native){notify('Disponible únicamente en la aplicación Android.');render();return;}
      if(t.checked){
        if(!state.channel[ch]?.enabled){notify('Primero habilita las notificaciones de este WhatsApp.');render();return;}
        if(!state.allowlist.some(x=>x.channel===ch)){notify('Primero autoriza al menos un contacto de prueba en este WhatsApp.');render();return;}
        if(!confirm('ATENCIÓN: Se responderán automáticamente mensajes de texto de contactos autorizados en '+channelNames[ch]+'. WhatsApp podría restringir el número. No hay garantía de entrega. ¿Activar para pruebas?')){render();return;}
      }
      state.settings.autoReplies[ch]=t.checked;save();render();notify('Autoenvío de texto '+(t.checked?'activado':'apagado')+' en '+channelNames[ch]);return;
    }
    if(t.dataset.channelToggle){const ch=t.dataset.channelToggle;state.channel[ch].enabled=t.checked;if(!t.checked)state.settings.autoReplies[ch]=false;save();render();notify('Captura '+(t.checked?'habilitada':'deshabilitada')+' en '+channelNames[ch]);return;}
    if(t.dataset.channelAssistant){state.channel[t.dataset.channelAssistant].assistant=t.value;save();render();return;}
    if(t.dataset.assistantToggle){state.assistants[t.dataset.assistantToggle].active=t.checked;save();render();return;}
    if(t.dataset.ruleToggle){const r=state.rules.find(x=>x.id===t.dataset.ruleToggle);if(r)r.active=t.checked;save();return;}
    if(t.dataset.setting){state.settings[t.dataset.setting]=t.checked;save();render();return;}
  });
  function applyImport(raw){try{const c=JSON.parse(raw);if(c.version!==1 || !c.channel || !Array.isArray(c.rules)||!Array.isArray(c.exceptions)||!Array.isArray(c.images))throw Error('Estructura incompatible');if(!confirm('¿Sustituir la configuración actual? Las imágenes físicas no se transfieren.'))return;state={...defaults(),...c,inbox:[],settings:{...defaults().settings,...c.settings,autoReplies:{normal:false,business:false}}};migrateScheduleConfig();save();setRoute('inicio');notify('Configuración importada.');}catch(e){notify('JSON no válido: '+e.message);}}
  $('#imageFile').addEventListener('change',async e=>{await addImageFile(e.target.files[0]);e.target.value='';});
  $('#configFile').addEventListener('change',async e=>{const file=e.target.files[0];if(file)applyImport(await file.text());e.target.value='';});
  window.addEventListener('pagehide',()=>{for(const url of imageUrls.values())URL.revokeObjectURL(url);});
  // Basic external test seam (never sends data).
  window.AutoResponderTest={respond,assistantFor,assignmentFor,departmentStatus,normalize,phoneKey,sameContact,pickImage,isImageValid,getConfig:()=>JSON.parse(JSON.stringify(state))};
  syncNativeCapture();loadNative().then(()=>render());
})();
