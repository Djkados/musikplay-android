# AutoResponder Pro 0.5.4 — diagnóstico de notificaciones

- Indicadores de permiso de Android, conexión del servicio y sincronización de reglas.
- Contadores por WhatsApp para eventos recibidos, incluso si la captura está apagada.
- Mensajes de diagnóstico para descartes (resúmenes, mensajes propios, avisos duplicados, antiguos o multimedia), sin almacenar su contenido.
- Botón «Comprobar conexión» para solicitar reconexión del servicio, sin enviar mensajes ni conceder permisos por sí solo.
- Botones para ajustes de notificaciones y página de información de la aplicación Android.
- Revisión al volver de Ajustes y mejora del diagnóstico en el panel.
- Ambas respuestas automáticas permanecen apagadas por defecto para instalaciones nuevas.

El acceso a notificaciones se concede manualmente en Android. Una compilación exitosa no demuestra recepción real de mensajes: probar con un contacto autorizado y un mensaje nuevo.
