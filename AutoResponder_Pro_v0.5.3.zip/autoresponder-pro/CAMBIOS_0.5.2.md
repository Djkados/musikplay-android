# AutoResponder Pro 0.5.2 — Barras de Android corregidas

Corrección enfocada en Android 15/16 con targetSdk 35 y navegación por gestos o tres botones.

- La WebView ya no recibe el padding directo de las barras del sistema. Ahora vive dentro de un FrameLayout nativo ajustado con WindowInsetsCompat.
- El área útil excluye el reloj/barra de estado, el recorte de cámara, la barra de navegación y el teclado virtual. Se vuelve a calcular al girar la pantalla y cambiar el modo de navegación.
- Contraste de íconos: blancos sobre el fondo oscuro de AutoResponder Pro.
- Permite que los diálogos fijos de revisión y los botones de la parte inferior permanezcan dentro del área visible.
- Preserva todo lo implementado en 0.5.1: contactos manuales/nativos, horarios independientes de MoviePlay/Las Tres M, reglas, pruebas y confirmación manual de imágenes.
- Los envíos automáticos siguen apagados por defecto.

**Pruebas manuales en dispositivo:** abrir Inicio, Contactos, Horarios, Reglas y Revisión multimedia; verificar que reloj y botones de navegación no tapen contenidos, abrir teclado, rotar pantalla y comprobar ambas formas de navegación.

**Instalación:** una APK debug generada por un ejecutor distinto puede tener otra clave de firma. Si Android no permite actualizar, exporta la configuración desde Ajustes antes de desinstalar la versión anterior.
