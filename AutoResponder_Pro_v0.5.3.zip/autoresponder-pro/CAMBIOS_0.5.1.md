# AutoResponder Pro 0.5.1 — Corrección Android

- El formulario ahora acepta directamente un número de WhatsApp (7 a 15 dígitos), sin exigir un contacto guardado.
- Botón nativo **Elegir de mis contactos Android**: ACTION_PICK para seleccionar un único registro telefónico, sin pedir READ_CONTACTS ni copiar la agenda completa.
- Número y nombre del contacto pueden guardarse como identificadores alternativos por canal. Si WhatsApp muestra un alias distinto del guardado, registra exactamente el nombre que aparece en la notificación o autoriza el contacto desde la bandeja.
- Adaptación visual para 320–430 px: barra superior, tarjetas, menús, botones, formularios, calendario y revisiones sin desbordamientos horizontales.
- Sigue siendo una app experimental: autoenvío apagado inicialmente, permite únicamente contactos autorizados y no envía imágenes sin confirmación.
- Antes de reinstalar, usa el botón **Exportar configuración** en Ajustes. Las APK debug pueden firmarse con claves diferentes, por lo que Android podría pedir desinstalar la anterior, borrando datos locales.
