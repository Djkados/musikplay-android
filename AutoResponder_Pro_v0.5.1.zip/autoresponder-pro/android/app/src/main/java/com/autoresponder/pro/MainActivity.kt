package com.autoresponder.pro

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.provider.ContactsContract
import org.json.JSONObject
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import android.webkit.WebResourceRequest
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File

/**
 * Offline-first WebView host. The dashboard runs exclusively from app assets.
 * Media sharing always requires manual confirmation. Experimental text replies require explicit opt-in per WhatsApp and contact.
 */
class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var fileCallback: android.webkit.ValueCallback<Array<Uri>>? = null
    private val chooseFileRequestCode = 4102
    private val chooseContactRequestCode = 4103

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false // Local files are served by WebViewAssetLoader.
            allowContentAccess = true
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            setSupportMultipleWindows(false)
            useWideViewPort = true
            loadWithOverviewMode = true
            textZoom = 100
        }
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        webView.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme == "https" && uri.host == "appassets.androidplatform.net" && uri.path?.startsWith("/assets/") == true) return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri)); true
                } catch (_: Exception) { true }
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: android.webkit.ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    startActivityForResult(fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE)
                    }, chooseFileRequestCode)
                    true
                } catch (_: ActivityNotFoundException) {
                    fileCallback = null
                    filePathCallback?.onReceiveValue(null)
                    false
                }
            }
        }
        // The bridge is restricted to the local, bundled UI; no remote website is loaded here.
        webView.addJavascriptInterface(Bridge(), "AndroidBridge")
        // Prevent Android 15+ status/navigation bars from covering dashboard controls.
        ViewCompat.setOnApplyWindowInsetsListener(webView) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    @Deprecated("Handled by WebView file chooser")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == chooseContactRequestCode) {
            if (resultCode != RESULT_OK || data?.data == null) return
            try {
                // Android grants temporary read access to the specific selected phone row.
                // No READ_CONTACTS permission is requested and the entire address book is never read.
                val selected = data.data ?: return
                contentResolver.query(selected, arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val name = cursor.getString(0) ?: ""
                        val phone = cursor.getString(1) ?: ""
                        val payload = JSONObject().put("name", name).put("phone", phone)
                        webView.evaluateJavascript("window.onAndroidContactSelected(${payload});", null)
                    }
                }
            } catch (_: SecurityException) { toast("Android no autorizó leer ese contacto.") }
              catch (_: Exception) { toast("No fue posible obtener el número de ese contacto.") }
            return
        }
        if (requestCode == chooseFileRequestCode) {
            fileCallback?.onReceiveValue(
                if (resultCode == RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                else null
            )
            fileCallback = null
        }
    }

    private fun packageFor(channel: String): String? = when (channel) {
        "normal" -> "com.whatsapp"
        "business" -> "com.whatsapp.w4b"
        else -> null
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    inner class Bridge {
        @JavascriptInterface
        fun pickPhoneContact() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
                try { startActivityForResult(intent, chooseContactRequestCode) }
                catch (_: ActivityNotFoundException) { toast("No hay una app de contactos disponible. Escribe el número manualmente.") }
                catch (_: Exception) { toast("No se pudo abrir el selector de contactos.") }
            }
        }

        @JavascriptInterface
        fun openNotificationSettings() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }

        @JavascriptInterface
        fun getInbox(): String = getSharedPreferences("private_inbox", MODE_PRIVATE)
            .getString("items", "[]") ?: "[]"

        /** Opt-in capture per application. Both channels start OFF. */
        @JavascriptInterface
        fun setCaptureChannels(normal: Boolean, business: Boolean) {
            getSharedPreferences("capture_config", MODE_PRIVATE).edit()
                .putBoolean("normal", normal).putBoolean("business", business).apply()
        }

        /** The web panel shares only policy/rules/schedules with the native notification listener.
         *  Never persist image bytes, inbox contents, credentials or web origins here.
         */
        @JavascriptInterface
        fun syncAutomationConfig(json: String) {
            if (json.length > 180_000) return
            try {
                val policy = org.json.JSONObject(json)
                if (policy.optInt("version") != 1 || !policy.has("channel") || !policy.has("schedules")) return
                getSharedPreferences("automation_rules", MODE_PRIVATE).edit()
                    .putString("config",policy.toString()).apply()
            } catch (_: Exception) { /* Ignore malformed policy. */ }
        }

        @JavascriptInterface
        fun getAutoReplyState(): String = getSharedPreferences("automation_rules", MODE_PRIVATE)
            .getString("config", "") ?: ""

        @JavascriptInterface
        fun clearInbox() { getSharedPreferences("private_inbox", MODE_PRIVATE).edit().putString("items", "[]").apply() }

        @JavascriptInterface
        fun shareText(text: String, channel: String) {
            val pkg = packageFor(channel) ?: return
            if (text.isBlank() || text.length > 5000) return
            runOnUiThread {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                    setPackage(pkg)
                }
                try {
                    startActivity(intent)
                    toast("Confirma el destinatario y envía desde WhatsApp.")
                } catch (_: ActivityNotFoundException) {
                    toast("No se encontró el WhatsApp seleccionado.")
                }
            }
        }

        @JavascriptInterface
        fun shareImage(base64: String, mime: String, caption: String, channel: String) {
            val pkg = packageFor(channel) ?: return
            if (base64.length > 6_000_000 || !setOf("image/jpeg", "image/png", "image/webp").contains(mime)) return
            try {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                if (bytes.size > 4_500_000 || bytes.isEmpty()) return
                val extension = when(mime) { "image/png" -> "png"; "image/webp" -> "webp"; else -> "jpg" }
                val directory = File(cacheDir, "shared_media").also { it.mkdirs() }
                // Different filenames avoid sharing the wrong media when two reviews overlap.
                directory.listFiles()?.filter { it.isFile && System.currentTimeMillis() - it.lastModified() > 60 * 60 * 1000L }
                    ?.forEach { it.delete() }
                val file = File(directory, "publicidad_${java.util.UUID.randomUUID()}.$extension")
                file.writeBytes(bytes)
                val uri = FileProvider.getUriForFile(this@MainActivity,"$packageName.fileprovider",file)
                runOnUiThread {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = mime
                        putExtra(Intent.EXTRA_STREAM, uri)
                        if (caption.isNotBlank()) putExtra(Intent.EXTRA_TEXT, caption.take(1500))
                        clipData = ClipData.newUri(contentResolver, "Publicidad", uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        setPackage(pkg)
                    }
                    try {
                        startActivity(intent)
                        toast("Verifica el contacto y confirma el envío en WhatsApp.")
                    } catch (_: ActivityNotFoundException) {
                        toast("No se encontró el WhatsApp seleccionado.")
                    }
                }
            } catch (_: Exception) {
                runOnUiThread { toast("No se pudo preparar la imagen.") }
            }
        }
    }

    @Deprecated("Uses legacy Android back navigation")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
