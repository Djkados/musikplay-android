package com.autoresponder.pro

import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.TemporalAdjusters
import java.util.Locale

/**
 * Local-only deterministic reply selection. Fail closed whenever a channel, contact,
 * business, rule or schedule cannot be verified. No backend, no chat scraping.
 * This class selects text only; sending is the NotificationListener's responsibility.
 */
internal object NativeAutoReplyEngine {
    private val colombia = ZoneId.of("America/Bogota")
    private val unsafe = Regex("\\b(otp|codigo de verificacion|codigo de acceso|contrasena|password|clave|pin bancario|token|clave dinamica)\\b")
    private val support = Regex("\\b(soporte|garantia|garantias|no funciona|fallando|caida|se cayo|error|problema|pin|contrasena|codigo de acceso|cuenta bloqueada|no abre|pantalla negra)\\b")
    private val movie = listOf("movieplay", "netflix", "disney", "prime video", "paramount", "max premium", "youtube premium", "streaming", "crunchyroll", "vix", "iptv", "nuplin", "flujo tv")
    private val food = listOf("las tres m", "hamburguesa", "hamburguesas", "perro caliente", "patacon", "chuzo", "arepa", "butifarra", "comidas rapidas", "domicilio de comida", "menu de comidas", "salchipapa")

    data class Decision(val text: String? = null, val business: String? = null, val department: String? = null, val reason: String = "")

    fun normalize(raw: String): String = Normalizer.normalize(raw.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "").replace(Regex("\\s+"), " ").trim()

    private fun matches(items: JSONArray?, channel: String, contact: String): Boolean {
        if (items == null) return false
        for (i in 0 until items.length()) {
            val item = items.optJSONObject(i) ?: continue
            if (item.optString("channel") == channel && normalize(item.optString("contact")) == normalize(contact)) return true
        }
        return false
    }

    private fun assignedBusiness(config: JSONObject, channel: String, contact: String, message: String): String? {
        val exceptions = config.optJSONArray("exceptions")
        var chosen: String? = null
        if (exceptions != null) for (i in 0 until exceptions.length()) {
            val item = exceptions.optJSONObject(i) ?: continue
            if (item.optString("channel") == channel && normalize(item.optString("contact")) == normalize(contact)) {
                chosen = item.optString("assistant")
                break
            }
        }
        if (chosen == null || chosen == "auto") {
            chosen = config.optJSONObject("channel")?.optJSONObject(channel)?.optString("assistant") ?: "none"
        }
        if (chosen != "auto") return chosen
        val normalized = normalize(message)
        val mentionsMovie = movie.any { normalized.contains(it) }
        val mentionsFood = food.any { normalized.contains(it) }
        return when {
            mentionsMovie && !mentionsFood -> "movieplay"
            mentionsFood && !mentionsMovie -> "tresm"
            else -> null  // Ask for clarification manually, not via unattended automatic reply.
        }
    }

    private fun easter(year: Int): LocalDate {
        val a=year%19; val b=year/100; val c=year%100; val d=b/4; val e=b%4
        val f=(b+8)/25; val g=(b-f+1)/3; val h=(19*a+b-d-g+15)%30
        val i=c/4; val k=c%4; val l=(32+2*e+2*i-h-k+7)%7
        val m=(a+11*h+22*l)/451
        return LocalDate.of(year,(h+l-7*m+114)/31,((h+l-7*m+114)%31)+1)
    }
    private fun monday(day: LocalDate): LocalDate = day.with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY))
    private fun isColombianHoliday(day: LocalDate): Boolean {
        val y=day.year
        val e=easter(y)
        val fixed=listOf(LocalDate.of(y,1,1),LocalDate.of(y,5,1),LocalDate.of(y,7,20),LocalDate.of(y,8,7),LocalDate.of(y,12,8),LocalDate.of(y,12,25))
        val moved=listOf(1 to 6,3 to 19,6 to 29,8 to 15,10 to 12,11 to 1,11 to 11).map { monday(LocalDate.of(y,it.first,it.second)) }
        val easterRelated=listOf(e.minusDays(3),e.minusDays(2),monday(e.plusDays(39)),monday(e.plusDays(60)),monday(e.plusDays(68)))
        return day in fixed || day in moved || day in easterRelated
    }

    private fun minutes(s: String): Int? {
        if (!Regex("^([01]\\d|2[0-3]):[0-5]\\d$").matches(s)) return null
        return s.substring(0,2).toInt()*60+s.substring(3,5).toInt()
    }

    private fun scheduledReply(config: JSONObject, business: String, unit: String, now: ZonedDateTime): Decision? {
        val schedule = config.optJSONObject("schedules")?.optJSONObject(business)?.optJSONObject(unit)
            ?: return Decision(reason="Horario sin configurar (bloqueado)")
        val date = now.toLocalDate()
        var dayOfWeek = now.dayOfWeek.value % 7 // Sunday 0, Monday 1
        if (schedule.optString("holidayMode") == "sunday" && isColombianHoliday(date)) dayOfWeek = 0
        var day = schedule.optJSONObject("days")?.optJSONObject(dayOfWeek.toString())
        val overrides = config.optJSONArray("scheduleOverrides")
        if (overrides != null) for (i in 0 until overrides.length()) {
            val o = overrides.optJSONObject(i) ?: continue
            if (o.optString("assistant") == business && o.optString("unit") == unit && o.optString("date") == date.toString()) {
                day = when (o.optString("mode")) {
                    "closed" -> JSONObject().put("enabled",false)
                    "hours" -> JSONObject().put("enabled",true).put("start",o.optString("start")).put("end",o.optString("end"))
                    else -> JSONObject().put("enabled",false)
                }
            }
        }
        val from = minutes(day?.optString("start") ?: "")
        val to = minutes(day?.optString("end") ?: "")
        val at = now.hour*60 + now.minute
        val open = day?.optBoolean("enabled",false) == true && from != null && to != null && from < to && at in from until to
        if (open) return null
        val away = schedule.optString("away").trim()
        return if (away.isNotEmpty() && away.length <= 1600) Decision(text=away,business=business,department=unit,reason="Fuera de horario")
               else Decision(reason="Sin mensaje de ausencia válido")
    }

    fun decide(config: JSONObject, channel: String, contact: String, message: String, now: ZonedDateTime = ZonedDateTime.now(colombia)): Decision {
        if (channel != "normal" && channel != "business") return Decision(reason="Canal no reconocido")
        val channelConfig = config.optJSONObject("channel")?.optJSONObject(channel)
            ?: return Decision(reason="Canal sin configurar")
        if (!channelConfig.optBoolean("enabled",false)) return Decision(reason="Canal desactivado")
        val auto = config.optJSONObject("settings")?.optJSONObject("autoReplies")?.optBoolean(channel,false) ?: false
        if (!auto) return Decision(reason="Respuesta automática desactivada")
        val c=contact.trim(); val m=message.trim()
        if(c.isEmpty() || c.length>140 || m.length !in 1..1000) return Decision(reason="Datos de notificación no confiables")
        if(unsafe.containsMatchIn(normalize(m))) return Decision(reason="Mensaje con posibles datos sensibles")
        if(matches(config.optJSONArray("blocked"),channel,c)) return Decision(reason="Contacto excluido")
        // ALWAYS require affirmative allowlist for unattended sending, even if the dashboard allows unrestricted drafting.
        if(!matches(config.optJSONArray("allowlist"),channel,c)) return Decision(reason="Contacto no autorizado para autoenvío")
        val paused=config.optJSONArray("paused")
        if(paused!=null)for(i in 0 until paused.length()){
            val item=paused.optJSONObject(i)?:continue
            if(item.optString("channel")==channel && normalize(item.optString("contact"))==normalize(c) && item.optLong("until",0L)>now.toInstant().toEpochMilli()) return Decision(reason="Atención manual pausada")
        }
        val business=assignedBusiness(config,channel,c,m) ?: return Decision(reason="Negocio ambiguo: revisión manual")
        if(business=="none" || !listOf("movieplay","tresm","personal").contains(business))return Decision(reason="Sin asistente asignado")
        if(!config.optJSONObject("assistants")?.optJSONObject(business).let {it?.optBoolean("active",false)==true})return Decision(reason="Asistente inactivo")
        val unit=when(business){
            "movieplay" -> if(support.containsMatchIn(normalize(m))) "support" else "sales"
            "tresm" -> "orders"
            else -> ""
        }
        if(unit.isNotEmpty())scheduledReply(config,business,unit,now)?.let {return it}
        val rules=config.optJSONArray("rules") ?: return Decision(reason="Sin reglas")
        var best: JSONObject?=null;var score=0
        for(i in 0 until rules.length()){
            val rule=rules.optJSONObject(i) ?: continue
            if(!rule.optBoolean("active",false) || rule.optString("assistant")!=business)continue
            val points=rule.optString("keywords").split(",").map{normalize(it)}.filter{it.isNotEmpty()}.sumOf { if(normalize(m).contains(it)) maxOf(it.length,4) else 0 }
            if(points>score){score=points;best=rule}
        }
        if(best==null)return Decision(reason="Consulta sin regla aprobada")
        val reply=best.optString("response").trim()
        if(reply.isEmpty() || reply.length>1600) return Decision(reason="Respuesta no válida")
        return Decision(text=reply,business=business,department=unit,reason="Regla configurada")
    }
}
