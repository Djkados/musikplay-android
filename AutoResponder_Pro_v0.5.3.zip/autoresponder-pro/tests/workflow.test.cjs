const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const engine = require('../web/schedule-engine.js');
const js = fs.readFileSync(path.join(__dirname,'../web/app.js'),'utf8');
const base = {
 version:1,
 channel:{normal:{enabled:true,assistant:'personal'},business:{enabled:true,assistant:'movieplay'}},
 assistants:{movieplay:{active:true},tresm:{active:true},personal:{active:true}},
 exceptions:[],allowlist:[{id:'a',channel:'business',contact:'Cliente Autorizado'}],blocked:[],paused:[],
 rules:[
  {id:'netflix',assistant:'movieplay',keywords:'netflix,precio netflix',response:'Planes Netflix aprobados',imageTag:'netflix',active:true},
  {id:'burger',assistant:'tresm',keywords:'hamburguesa',response:'Menú Las Tres M',imageTag:'menu',active:true}
 ],
 images:[
  {id:'expired',assistant:'movieplay',tags:'netflix',active:true,validUntil:'2026-10-01',createdAt:1},
  {id:'valid',assistant:'movieplay',tags:'netflix, netflix 4k',active:true,validFrom:'2026-10-05',validUntil:'2099-10-31',createdAt:2},
  {id:'otherbiz',assistant:'tresm',tags:'netflix,menu',active:true,validUntil:'2099-10-31',createdAt:9},
  {id:'inactive',assistant:'movieplay',tags:'netflix',active:false,createdAt:200}
 ],settings:{requireAllowlist:true,blockGroups:true,reviewOnly:true},inbox:[]
};
function run(config){
 const storage = new Map([['autoresponder_pro_v1', JSON.stringify(config)]]);
 const node=()=>({textContent:'',value:'',innerHTML:'',classList:{add(){},remove(){},toggle(){}},addEventListener(){},querySelectorAll(){return[]}});
 const elements=new Map();
 const document={querySelector(s){if(!elements.has(s))elements.set(s,node());return elements.get(s);},querySelectorAll(){return[];},addEventListener(){},createElement(){return node()}};
 let capture;
 const bridge={shareText(){},setCaptureChannels(normal,business){capture={normal,business}},getInbox(){return '[]'},clearInbox(){}};
 const context={document,window:{ScheduleEngine:engine,AndroidBridge:bridge,addEventListener(){}},localStorage:{getItem(k){return storage.get(k)||null},setItem(k,v){storage.set(k,v)}},console,setTimeout,clearTimeout,Date,Math,URL,Blob,FileReader:function(){},indexedDB:{open(){throw Error('Unexpected indexedDB use')}},navigator:{},confirm:()=>true,prompt:()=>null};
 vm.runInNewContext(js,context);
 return {api:context.window.AutoResponderTest,capture};
}
const {api,capture}=run(base);
assert.deepEqual(capture,{normal:true,business:true},'Native capture channel selection must be independent');
assert.equal(api.pickImage('movieplay','netflix','2026-10-10').id,'valid','Expired and foreign assistant images ignored');
assert.equal(api.pickImage('movieplay','netflix','2026-10-04'),null,'Not-yet-active promotion ignored');
assert.equal(api.pickImage('movieplay','', '2026-10-10'),null,'Blank tags never match');
assert.equal(api.pickImage('tresm','menu','2026-10-10').id,'otherbiz');
assert.equal(api.respond('business','Cliente Autorizado','Precio Netflix').image.id,'valid');
assert.match(api.respond('business','Desconocido','Netflix').reason,/sin permiso/);
assert.match(api.respond('normal','Cliente Autorizado','Netflix').reason,/sin permiso/);
assert.match(api.respond('business','Cliente Autorizado','PIN 1234').reason,/seguridad/);
assert.match(api.respond('business','Cliente Autorizado','Netflix',true).reason,/grupos/);
const blocked=JSON.parse(JSON.stringify(base));blocked.blocked.push({id:'z',channel:'business',contact:'Cliente Autorizado'});
assert.match(run(blocked).api.respond('business','Cliente Autorizado','Netflix').reason,/bloqueado/);
const inactive=JSON.parse(JSON.stringify(base));inactive.channel.business.enabled=false;
assert.equal(run(inactive).capture.business,false);
assert.match(run(inactive).api.respond('business','Cliente Autorizado','Netflix').reason,/desactivado/);
console.log('OK — 12 verificaciones de canales, privacidad, reglas e imágenes vigentes.');

// 0.5.1 regression: manually typed numbers, contact picker aliases, and channel isolation.
assert.equal(api.phoneKey('+57 300 123 4567'),'3001234567');
assert.equal(api.phoneKey('300 123 4567'),'3001234567');
assert.equal(api.phoneKey('123'),'');
assert.equal(api.sameContact({contact:'Persona Prueba',phone:'3001234567'},'+57 300 123 4567'),true);
assert.equal(api.sameContact({contact:'Persona Prueba',phone:'3001234567'},'Persona Prueba'),true);
assert.equal(api.sameContact({contact:'Persona Prueba',phone:'3001234567'},'Otro contacto'),false);
const picked=JSON.parse(JSON.stringify(base));
picked.allowlist=[{id:'phone',channel:'business',contact:'Persona Prueba',phone:'3001234567'}];
picked.exceptions=[{id:'exc',channel:'business',contact:'Persona Prueba',phone:'3001234567',assistant:'tresm'}];
const pickedApi=run(picked).api;
assert.equal(pickedApi.assistantFor('business','+57 300 123 4567','hamburguesa'),'tresm');
assert.equal(pickedApi.assistantFor('business','Persona Prueba','hamburguesa'),'tresm');
assert.match(pickedApi.respond('normal','+57 300 123 4567','hamburguesa').reason,/sin permiso/);
console.log('OK — contactos Android, números con +57, excepciones y separación por canal.');
