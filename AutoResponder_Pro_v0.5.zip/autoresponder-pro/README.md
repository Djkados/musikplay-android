# AutoResponder Pro 0.5 — Android con texto automático de prueba

**Nuevo en 0.5:** autoenvío de TEXTO opcional por cada WhatsApp, con controles independientes y estricta lista de contactos autorizados, pausas manuales, deduplicación y horario del negocio. El envío de IMÁGENES siempre requiere confirmación manual. La respuesta directa se intenta solo a través de `RemoteInput` cuando la notificación lo ofrece; no hay API oficial ni garantía de recepción o ausencia de restricciones. Sin hosting obligatorio ni IA generativa. Lee `NOVEDADES_0.5.md` antes de habilitarlo.

**Versión 0.4:** recursos de identidad Android, ajuste de barras del sistema, workflow de compilación gratuito con pruebas y artefacto de retención corta. Ver `DESPLIEGUE_GRATIS.md`.

# AutoResponder Pro 0.5 — panel multiempresa con horarios separados

**Estado:** prototipo de configuración y revisión local. Se entrega código fuente de Android y panel HTML sin dependencias de hosting. **No hay APK compilado, envíos automáticos de texto, API de WhatsApp ni IA generativa** en este paquete. El flujo de compartir texto/imágenes requiere aprobación final dentro de WhatsApp. Sin API oficial no se garantiza ausencia de restricciones de Meta.

## Novedades frente a 0.2

- **Horarios independientes por área**: MoviePlay Ventas (todos los días 09:00–22:00), MoviePlay Soporte (lunes-sábado 09:00–22:00; domingos y festivos 09:00–17:00), Las Tres M Pedidos (sábados y domingos 18:00–22:30). Zona horaria `America/Bogota`, hora colombiana.
- **Festivos de Colombia automáticos**: cálculo local por año (incluye fechas trasladadas al lunes y Semana Santa). Los festivos afectan al soporte de MoviePlay, no abren automáticamente Las Tres M entre semana.
- **Cierres y turnos especiales por fecha y área**: puedes cerrar Las Tres M un fin de semana o extender un horario sin modificar el otro negocio.
- **Detección conservadora de negocio en ambos WhatsApp**: si el mensaje menciona un producto claramente específico, elige MoviePlay o Las Tres M. Ante preguntas genéricas («¿cuál es el horario?»), pide aclaración. No mezcla horarios para producir una respuesta.
- **Prioridad de asignaciones**: excepción explícita por contacto y canal > asistente fijo del canal > detección del negocio (si el canal está en modo auto) > aclaración.
- **Simulador con fecha/hora de Bogotá**: permite ensayar cierre de domingos, festivos, horarios de ventas y casos ambiguos antes de usar el teléfono.
- **Interfaz profesional adaptativa**: editor de horarios en secciones plegables, cambios guardados por área, fecha especial y mensajes de ausencia editables; probada a 360, 390, 430, 900 y 1280 píxeles.
- **Biblioteca con editor de imagen**: reemplaza la secuencia de diálogos emergentes; nombre, negocio, palabras clave y vigencia se ajustan en un solo formulario.

## Primera configuración (5 minutos)

1. Abre `AutoResponder_Pro_Demo.html` en un navegador compatible y entra a **Inicio**. Pulsa **Activar detección en ambos**, que asigna el modo «Detectar negocio» a WhatsApp normal y Business. Esto **no** enciende los canales, que por seguridad inician desactivados.
2. Entra a **Horarios y festivos**. Verás tres tarjetas: **Ventas**, **Soporte** y **Pedidos**. Para cambiar un horario, despliega *Editar días, festivos y mensaje de ausencia*, elige cada día de la semana, cambia las horas y el texto de ausencia. Los cambios se guardan localmente.
3. Para un cierre especial, en **Excepciones y cierres especiales** elige el área exacta, la fecha y «No habrá atención»; o elige «Horario especial» y define apertura/cierre. El cambio tiene prioridad sobre el calendario semanal y los festivos.
4. Para probar de forma controlada, habilita temporalmente **un canal** en Inicio y agrega un nombre visible a **Contactos y excepciones → Autorizar para pruebas**. Puedes crear una excepción para asignar un asistente fijo a un contacto.
5. Entra al **Simulador**; selecciona la fecha/hora colombiana, el canal y una consulta (p. ej. «Netflix», «hamburguesa» o «¿cuál es el horario?»). Debe verse qué empresa responde y si el área está abierta o cerrada. Ningún mensaje se envía por usar el simulador.

### Tabla de prioridad del motor

| Condición | Resultado |
|---|---|
| Canal apagado o grupo excluido o contacto bloqueado | No se genera respuesta |
| Contacto no autorizado en modo pruebas | No se genera respuesta |
| Contacto con excepción explícita | Se usa su asistente indicado en ese WhatsApp |
| Canal en asistente fijo | Se usa el asistente fijo |
| Canal en «Detectar negocio» y producto inequívoco | Se asigna MoviePlay o Las Tres M, indistintamente del WhatsApp |
| Canal en «Detectar negocio» y consulta ambigua | Pregunta a cuál negocio se refiere; **no envía horarios equivocados** |
| Negocio identificado, pero departamento cerrado | Ofrece exclusivamente el mensaje de ausencia de ese departamento |
| Negocio identificado y departamento abierto | Aplica la regla aprobada; puede sugerir imagen vigente del mismo negocio |

**Ejemplos de horarios**

- Domingo 18:00 en Bogotá: MoviePlay **Ventas abiertas**, **Soporte cerrado**, Las Tres M **Pedidos abiertos**.
- Lunes festivo 19:00: MoviePlay **Ventas abiertas**, **Soporte cerrado**, Las Tres M **Pedidos cerrados**, salvo excepción de apertura.
- Sábado con excepción de cierre únicamente en Las Tres M: el soporte y ventas de MoviePlay no cambian.

## Archivos

```
AutoResponder_Pro_Demo.html   Panel independiente en un archivo
web/index.html               Interfaz fuente
web/styles.css               Diseño adaptable
web/schedule-engine.js       Motor horario, festivos colombianos y detección de negocio
web/app.js                   Motor de reglas, formularios, imágenes y simulador
android/                     Proyecto Android (Kotlin + WebView + notificaciones)
android/app/src/main/assets/ Copia local del panel web completo
.github/workflows/            Workflow para compilar APK debug manualmente en GitHub Actions
GUIA_PRUEBAS.md               Pruebas y limitaciones
/tests/                      Pruebas automáticas
```

### Verificaciones de código

Con Node.js instalado:

```bash
node tests/smoke.test.cjs
node tests/workflow.test.cjs
node tests/schedules.test.cjs
```

Se comprobaron los horarios y festivos de 2026, la detección conservadora de negocio, las excepciones, seguridad y las reglas. Se probó el panel con Chromium headless a 360/390/430/900/1280 píxeles, sin desbordamiento horizontal. **No se verificó el APK en un teléfono real.**

### Compilación Android (opcional)

- Se requiere Android SDK 35, Android Gradle Plugin 8.9.2, Gradle 8.11.1 y Java 17. El ZIP no incluye `gradle-wrapper.jar` ni ejecutables de terceros.
- Abre `android/` como proyecto en Android Studio y utiliza **Build APK(s)** / `assembleDebug`.
- Como alternativa, puedes subir el contenido de la carpeta `autoresponder-pro/` a un repositorio **privado** y ejecutar manualmente `Actions → Compilar APK de prueba`. GitHub Actions tiene cuotas y posibles cargos según el plan; compruébalos antes de ejecutarlo.
- El APK **no fue compilado** aquí; no hay confirmación de compatibilidad en un teléfono concreto.

## Privacidad, sincronización y limitaciones

- Ambas instalaciones (panel web en PC y WebView Android) trabajan con almacenamiento local independiente. **No existe todavía sincronización remota entre Android y PC**. Puedes exportar/importar reglas y horarios por JSON, pero las imágenes originales no viajan dentro del archivo exportado.
- Las excepciones de contactos se relacionan con el nombre visible de las notificaciones y el canal, **no con un número de teléfono verificado**. Usa listas autorizadas mientras pruebas, confirma siempre el destinatario al compartir y evita automatización masiva.
- WhatsApp puede ocultar o agrupar notificaciones; la captura necesita permiso y puede verse afectada por restricciones de batería. No hay acceso garantizado al historial de chats.
- El motor de detección usa expresiones y reglas locales; **todavía no es IA generativa**. No inventa respuestas cuando no tiene regla confiable.
- La app no simula toques ni envía imágenes automáticamente. Abre el selector de compartir y tú confirmas en WhatsApp el destinatario y el envío. Abrirlo no acredita entrega.
- La zona horaria de todas las decisiones se fija en `America/Bogota` sin depender del huso horario del teléfono. Los festivos del algoritmo son los nacionales de Colombia; excepciones locales o cierres de un negocio deben configurarse por fecha.

**AutoResponder Pro es un proyecto independiente; no está afiliado con Meta o WhatsApp.**
