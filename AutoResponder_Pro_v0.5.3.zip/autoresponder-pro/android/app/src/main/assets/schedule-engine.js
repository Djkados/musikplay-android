/* AutoResponder Pro v0.3 — motor de horarios y enrutamiento, sin dependencias. */
(function(root, factory) {
  const api=factory();
  if(typeof module==='object' && module.exports) module.exports=api;
  if(root) root.ScheduleEngine=api;
})(typeof window!=='undefined'?window:null,function(){
  'use strict';
  const ZONE='America/Bogota';
  const days=['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
  const units=[
    {id:'movieplay:sales',assistant:'movieplay',unit:'sales',label:'MoviePlay · Ventas',icon:'🎬'},
    {id:'movieplay:support',assistant:'movieplay',unit:'support',label:'MoviePlay · Soporte',icon:'🛟'},
    {id:'tresm:orders',assistant:'tresm',unit:'orders',label:'Las Tres M · Pedidos',icon:'🍔'}
  ];
  const row=(enabled,start,end)=>({enabled,start,end});
  function defaultSchedules(){
    const every=(start,end)=>Object.fromEntries(Array.from({length:7},(_,n)=>[n,row(true,start,end)]));
    const weekends=Object.fromEntries(Array.from({length:7},(_,n)=>[n,row(n===0||n===6,'18:00','22:30')]));
    return {
      movieplay:{
        sales:{days:every('09:00','22:00'),holidayMode:'normal',away:'¡Hola! 🎬 Gracias por escribir a MoviePlay. Nuestro horario de VENTAS es todos los días de 9:00 a. m. a 10:00 p. m. Te atenderemos en el próximo horario disponible.'},
        support:{days:{...every('09:00','22:00'),0:row(true,'09:00','17:00')},holidayMode:'sunday',away:'¡Hola! 🛟 El soporte de MoviePlay atiende de lunes a sábado de 9:00 a. m. a 10:00 p. m.; domingos y festivos de 9:00 a. m. a 5:00 p. m. Tu solicitud quedará pendiente para el siguiente horario de atención.'}
      },
      tresm:{orders:{days:weekends,holidayMode:'normal',away:'¡Hola! 🍔 Gracias por escribir a Las Tres M. Atendemos sábados y domingos de 6:00 p. m. a 10:30 p. m. en el barrio Ciudadela, La Ceja. Puedes consultar el menú en https://lastresm.netlify.app. Te responderemos en nuestro próximo horario de servicio.'}}
    };
  }
  const pad=v=>String(v).padStart(2,'0');
  const iso=(y,m,d)=>`${y}-${pad(m)}-${pad(d)}`;
  const utcDay=s=>new Date(`${s}T12:00:00Z`).getUTCDay();
  const addDays=(s,n)=>{const d=new Date(`${s}T12:00:00Z`);d.setUTCDate(d.getUTCDate()+n);return iso(d.getUTCFullYear(),d.getUTCMonth()+1,d.getUTCDate());};
  const monday=(s)=>addDays(s,(8-utcDay(s))%7);
  function easter(year){
    const a=year%19,b=Math.floor(year/100),c=year%100,d=Math.floor(b/4),e=b%4,f=Math.floor((b+8)/25),g=Math.floor((b-f+1)/3),h=(19*a+b-d-g+15)%30,i=Math.floor(c/4),k=c%4,l=(32+2*e+2*i-h-k+7)%7,m=Math.floor((a+11*h+22*l)/451),month=Math.floor((h+l-7*m+114)/31),day=((h+l-7*m+114)%31)+1;
    return iso(year,month,day);
  }
  function holidays(year){
    const e=easter(year);const result=[];
    const put=(date,name)=>result.push({date,name});
    const fixed=(month,day,name)=>put(iso(year,month,day),name);
    const moved=(month,day,name)=>put(monday(iso(year,month,day)),name);
    fixed(1,1,'Año Nuevo');moved(1,6,'Reyes Magos');moved(3,19,'San José');
    put(addDays(e,-3),'Jueves Santo');put(addDays(e,-2),'Viernes Santo');
    fixed(5,1,'Día del Trabajo');put(monday(addDays(e,39)),'Ascensión del Señor');
    put(monday(addDays(e,60)),'Corpus Christi');put(monday(addDays(e,68)),'Sagrado Corazón');
    moved(6,29,'San Pedro y San Pablo');fixed(7,20,'Independencia');fixed(8,7,'Batalla de Boyacá');
    moved(8,15,'Asunción de la Virgen');moved(10,12,'Día de la Raza');
    moved(11,1,'Todos los Santos');moved(11,11,'Independencia de Cartagena');
    fixed(12,8,'Inmaculada Concepción');fixed(12,25,'Navidad');
    return result.sort((a,b)=>a.date.localeCompare(b.date));
  }
  function bogotaParts(at=new Date()){
    const o={timeZone:ZONE,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false,hourCycle:'h23'};
    const parts=Object.fromEntries(new Intl.DateTimeFormat('en-US',o).formatToParts(at).filter(x=>x.type!=='literal').map(x=>[x.type,x.value]));
    const date=`${parts.year}-${parts.month}-${parts.day}`;
    const hh=parts.hour==='24'?'00':parts.hour;
    return {date,time:`${hh}:${parts.minute}`,day:utcDay(date),year:Number(parts.year)};
  }
  function parseBogotaLocal(str){
    if(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(str||''))throw Error('Fecha local inválida');
    const at=new Date(`${str}:00-05:00`);
    if(Number.isNaN(at.getTime())||`${bogotaParts(at).date}T${bogotaParts(at).time}`!==str)throw Error('Fecha no válida');
    return at;
  }
  const validHHMM=s=>/^([01]\d|2[0-3]):[0-5]\d$/.test(s||'');
  function validRange(a,b){return validHHMM(a)&&validHHMM(b)&&a<b;}
  function evaluate(schedules,overrides,assistant,unit,at=new Date()){
    const parts=bogotaParts(at);
    const conf=schedules?.[assistant]?.[unit];
    if(!conf)return {open:true,configured:false,parts,reason:'Sin horario definido',label:'Horario no definido'};
    const holiday=holidays(parts.year).find(x=>x.date===parts.date)||null;
    const special=(overrides||[]).filter(x=>x.assistant===assistant&&x.unit===unit&&x.date===parts.date).at(-1);
    let plan=conf.days?.[(holiday&&conf.holidayMode==='sunday')?0:parts.day];
    let reason=holiday?`Festivo en Colombia: ${holiday.name}`:days[parts.day];
    if(special){
      reason=special.note?`Excepción: ${special.note}`:'Excepción programada';
      if(special.mode==='closed')plan={enabled:false,start:'',end:''};
      if(special.mode==='hours')plan={enabled:true,start:special.start,end:special.end};
    }
    if(!plan || !plan.enabled || !validRange(plan.start,plan.end))return {open:false,configured:true,parts,reason,holiday,override:special||null,label:'Cerrado',range:null,away:conf.away};
    const open=parts.time>=plan.start&&parts.time<plan.end;
    return {open,configured:true,parts,reason,holiday,override:special||null,label:`${plan.start}–${plan.end}`,range:{start:plan.start,end:plan.end},away:conf.away};
  }
  // Strongly distinctive vocabulary only: "precio", "horario", "hola" and "servicio" are intentionally neutral.
  const keywordSets={
    movieplay:[['movieplay',12],['netflix',9],['disney',9],['prime video',9],['paramount',9],['max premium',9],['youtube premium',9],['streaming',8],['crunchyroll',9],['vix',8],['perfil de netflix',9],['renovar netflix',9],['servicio caido',8],['iptv',8],['nuplin',8],['flujo tv',8]],
    tresm:[['las tres m',12],['hamburguesa',9],['hamburguesas',9],['perro caliente',9],['patacon',9],['chuzo',9],['arepa',8],['butifarra',9],['comidas rapidas',9],['domicilio de comida',8],['menu de comidas',9],['pedido de hamburguesa',9],['salchipapa',8]]
  };
  const normalize=s=>String(s||'').toLocaleLowerCase('es').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim();
  function detectBusiness(message){
    const normalized=normalize(message),scores={movieplay:0,tresm:0};
    for(const [id,terms] of Object.entries(keywordSets))for(const [term,weight] of terms)if(normalized.includes(term))scores[id]+=weight;
    if(scores.movieplay>=8&&scores.tresm>=8)return {assistant:null,confidence:'mixed',scores,reason:'La consulta menciona ambos negocios.'};
    const best=scores.movieplay>scores.tresm?'movieplay':'tresm';
    if(scores[best]>=8 && scores[best]>scores[best==='movieplay'?'tresm':'movieplay'])return {assistant:best,confidence:'high',scores};
    return {assistant:null,confidence:'unknown',scores,reason:'No se identificó el negocio de manera confiable.'};
  }
  function phoneIdentity(raw){
    const digits=String(raw||'').replace(/\D/g,'');
    if(digits.length===12&&digits.startsWith('57'))return digits.slice(2);
    return digits.length>=7&&digits.length<=15?digits:'';
  }
  function sameContact(entry,value){
    const incoming=normalize(value);
    if(!incoming)return false;
    if([entry.contact,entry.phone].filter(Boolean).some(v=>normalize(v)===incoming))return true;
    const phone=phoneIdentity(value);
    return !!phone&&[entry.contact,entry.phone].some(v=>phoneIdentity(v)===phone);
  }
  function resolveAssignment(channel,contact,message,channels,exceptions){
    const special=(exceptions||[]).find(x=>x.channel===channel&&sameContact(x,contact));
    if(special && special.assistant!=='auto')return {assistant:special.assistant,method:'exception'};
    const selected=special?.assistant||channels?.[channel]?.assistant||'none';
    if(selected!=='auto')return {assistant:selected,method:'channel'};
    const detected=detectBusiness(message);
    if(detected.assistant)return {assistant:detected.assistant,method:'detected',confidence:detected.confidence};
    return {assistant:null,method:'clarify',confidence:detected.confidence,reason:detected.reason};
  }
  function determineUnit(assistant,message){
    if(assistant==='tresm')return 'orders';
    if(assistant!=='movieplay')return null;
    const txt=normalize(message);
    return /\b(soporte|garantia|garantias|no funciona|fallando|caida|se cayo|error|problema|pin|contrasena|codigo de acceso|cuenta bloqueada|no abre|pantalla negra)\b/.test(txt)?'support':'sales';
  }
  return {ZONE,days,units,defaultSchedules,holidays,easter,bogotaParts,parseBogotaLocal,validRange,evaluate,detectBusiness,resolveAssignment,determineUnit};
});
