package com.autoresponder.pro

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

class NativeAutoReplyEngineTest {
    private fun clock(day: String, hour: String) = ZonedDateTime.parse("${day}T${hour}:00-05:00[America/Bogota]")
    private fun config(): JSONObject {
        val days=JSONObject()
        val orders=JSONObject()
        val support=JSONObject()
        for (d in 0..6) {
            days.put("$d",JSONObject().put("enabled",true).put("start","09:00").put("end","22:00"))
            support.put("$d",JSONObject().put("enabled",true).put("start","09:00").put("end",if(d==0) "17:00" else "22:00"))
            orders.put("$d",JSONObject().put("enabled",d==0 || d==6).put("start","18:00").put("end","22:30"))
        }
        return JSONObject().apply {
            put("version",1)
            put("channel",JSONObject().put("normal",JSONObject().put("enabled",true).put("assistant","auto"))
                .put("business",JSONObject().put("enabled",true).put("assistant","auto")))
            put("settings",JSONObject().put("autoReplies",JSONObject().put("normal",false).put("business",true)))
            put("assistants",JSONObject().put("movieplay",JSONObject().put("active",true))
                .put("tresm",JSONObject().put("active",true)))
            put("allowlist",JSONArray().put(JSONObject().put("channel","business").put("contact","Prueba"))
                .put(JSONObject().put("channel","normal").put("contact","Prueba")))
            put("blocked",JSONArray());put("paused",JSONArray());put("exceptions",JSONArray());put("scheduleOverrides",JSONArray())
            put("schedules",JSONObject()
                .put("movieplay",JSONObject()
                    .put("sales",JSONObject().put("days",days).put("holidayMode","normal").put("away","Ventas cerradas"))
                    .put("support",JSONObject().put("days",support).put("holidayMode","sunday").put("away","Soporte cerrado")))
                .put("tresm",JSONObject().put("orders",JSONObject().put("days",orders).put("holidayMode","normal").put("away","Pedidos cerrados"))))
            put("rules",JSONArray()
                .put(JSONObject().put("assistant","movieplay").put("active",true).put("keywords","netflix").put("response","Precios MoviePlay"))
                .put(JSONObject().put("assistant","tresm").put("active",true).put("keywords","hamburguesa").put("response","Menú Las Tres M")))
        }
    }

    @Test fun optInAndAllowlistAreBothMandatory() {
        val c=config();val whenOpen=clock("2026-10-10","19:00")
        assertNull(NativeAutoReplyEngine.decide(c,"normal","Prueba","netflix",whenOpen).text)
        assertNull(NativeAutoReplyEngine.decide(c,"business","Desconocido","netflix",whenOpen).text)
        assertEquals("Precios MoviePlay",NativeAutoReplyEngine.decide(c,"business","Prueba","netflix",whenOpen).text)
    }
    @Test fun resolvesCompaniesIndependentlyOnSameWhatsapp() {
        val c=config();val whenOpen=clock("2026-10-10","19:00")
        assertEquals("Precios MoviePlay",NativeAutoReplyEngine.decide(c,"business","Prueba","Netflix",whenOpen).text)
        assertEquals("Menú Las Tres M",NativeAutoReplyEngine.decide(c,"business","Prueba","hamburguesa",whenOpen).text)
        assertNull(NativeAutoReplyEngine.decide(c,"business","Prueba","hola horario",whenOpen).text)
        assertNull(NativeAutoReplyEngine.decide(c,"business","Prueba","Netflix y hamburguesa",whenOpen).text)
    }
    @Test fun sundayMovieplaySupportAndSalesDiffer() {
        val c=config();val sunday=clock("2026-10-11","18:00")
        assertEquals("Precios MoviePlay",NativeAutoReplyEngine.decide(c,"business","Prueba","netflix",sunday).text)
        assertEquals("Soporte cerrado",NativeAutoReplyEngine.decide(c,"business","Prueba","problema netflix",sunday).text)
        assertEquals("Menú Las Tres M",NativeAutoReplyEngine.decide(c,"business","Prueba","hamburguesa",sunday).text)
    }
    @Test fun holidaySupportClosesEarlyAndFoodDoesNotOpen() {
        val c=config();val mondayHoliday=clock("2026-10-12","19:00")
        assertEquals("Soporte cerrado",NativeAutoReplyEngine.decide(c,"business","Prueba","problema netflix",mondayHoliday).text)
        assertEquals("Precios MoviePlay",NativeAutoReplyEngine.decide(c,"business","Prueba","netflix",mondayHoliday).text)
        assertEquals("Pedidos cerrados",NativeAutoReplyEngine.decide(c,"business","Prueba","hamburguesa",mondayHoliday).text)
    }
    @Test fun specialClosuresApplyOnlyOneBusiness() {
        val c=config();val saturday=clock("2026-10-10","19:00")
        c.getJSONArray("scheduleOverrides").put(JSONObject().put("assistant","tresm").put("unit","orders")
            .put("date","2026-10-10").put("mode","closed"))
        assertEquals("Pedidos cerrados",NativeAutoReplyEngine.decide(c,"business","Prueba","hamburguesa",saturday).text)
        assertEquals("Precios MoviePlay",NativeAutoReplyEngine.decide(c,"business","Prueba","netflix",saturday).text)
    }
    @Test fun blocksSensitivePausedExcludedAndDisabled() {
        val c=config();val t=clock("2026-10-10","19:00")
        assertNull(NativeAutoReplyEngine.decide(c,"business","Prueba","OTP netflix 123456",t).text)
        c.getJSONArray("paused").put(JSONObject().put("channel","business").put("contact","Prueba")
            .put("until",t.toInstant().toEpochMilli()+3600000))
        assertNull(NativeAutoReplyEngine.decide(c,"business","Prueba","netflix",t).text)
        c.put("paused",JSONArray())
        c.getJSONArray("blocked").put(JSONObject().put("channel","business").put("contact","Prueba"))
        assertNull(NativeAutoReplyEngine.decide(c,"business","Prueba","netflix",t).text)
    }
    @Test fun contactExceptionOverridesAutomaticDetection() {
        val c=config();val t=clock("2026-10-10","19:00")
        c.getJSONArray("exceptions").put(JSONObject().put("channel","business").put("contact","Prueba").put("assistant","tresm"))
        // A Netflix question assigned to food MUST NOT use Netflix pricing.
        assertNull(NativeAutoReplyEngine.decide(c,"business","Prueba","Netflix",t).text)
        assertEquals("Menú Las Tres M",NativeAutoReplyEngine.decide(c,"business","Prueba","hamburguesa",t).text)
    }
    @Test fun phonePickerAliasMatchesNameAndNumberButNotAnotherChannel() {
        val c=config();val t=clock("2026-10-10","19:00")
        c.put("allowlist",JSONArray().put(JSONObject().put("channel","business")
            .put("contact","Cliente Prueba").put("phone","3001234567")))
        assertEquals("Precios MoviePlay",NativeAutoReplyEngine.decide(c,"business","+57 300 123 4567","Netflix",t).text)
        assertEquals("Precios MoviePlay",NativeAutoReplyEngine.decide(c,"business","Cliente Prueba","Netflix",t).text)
        assertNull(NativeAutoReplyEngine.decide(c,"normal","+57 300 123 4567","Netflix",t).text)
        c.getJSONArray("exceptions").put(JSONObject().put("channel","business")
            .put("contact","Cliente Prueba").put("phone","3001234567").put("assistant","tresm"))
        assertEquals("Menú Las Tres M",NativeAutoReplyEngine.decide(c,"business","+57 300 123 4567","hamburguesa",t).text)
    }

}
