# AutoResponder Pro 0.5 · Respuesta de texto experimental

## Qué cambió

- En Android hay un control independiente **Recibir notificaciones** y **Responder texto automáticamente** por cada WhatsApp. Ambos **autoenvíos inician APAGADOS**.
- Una respuesta automática solo se intenta cuando: el canal está habilitado; el usuario activó explícitamente el autoenvío de ese WhatsApp; el contacto está en la lista autorizada de ese canal; no está bloqueado ni pausado; el negocio se puede resolver; y existe una regla o un texto de ausencia válido.
- Al detectar un mensaje ambiguo (por ejemplo, «¿cuál es el horario?»), no envía automáticamente un horario del negocio equivocado. Deja la consulta para revisión.
- Horarios propios: MoviePlay ventas, MoviePlay soporte (festivos y domingos) y Las Tres M pedidos. Horarios especiales por fecha y área.
- Android intenta responder usando `RemoteInput` de la notificación **solo si WhatsApp muestra una acción de respuesta directa**. No usa accesibilidad, no simula toques y no envía imágenes automáticamente.
- Límite de seguridad: 1 intento por conversación cada 10 minutos; deduplicación de notificaciones. Nunca se hacen envíos masivos.
- La bandeja indica «respuesta enviada a Android, sin confirmar entrega» o la razón de ausencia de envío. Botones para autorizar un contacto de prueba o pausar la conversación 1 hora.
- Botón «Detener autoenvío» que apaga los dos canales.
- El panel WebView ahora sincroniza reglas y horarios locales con el servicio nativo: lo que cambias en Android lo recibe el listener.
- Se mantiene la confirmación manual de imagen y destinatario dentro de WhatsApp.

## Precauciones y limitaciones

- **Sin garantía de funcionamiento continuo, entrega ni ausencia de bloqueo**: la automatización no oficial puede incumplir condiciones de WhatsApp/Business. Meta puede restringir la cuenta. Para reducir riesgos solo habilitamos contactos autorizados explícitamente.
- **La aplicación no detecta de forma fiable que respondiste manualmente desde WhatsApp**. Por eso la pausa se aplica manualmente desde Bandeja/Contactos. No prometemos pausa por intervención humana automática.
- WhatsApp puede ocultar mensajes, agruparlos o no ofrecer `RemoteInput`. En estos casos no se envía texto. Una llamada a la acción de respuesta directa exitosa NO equivale a confirmar recepción por el destinatario.
- Las coincidencias de contactos son por **nombre visible de la notificación y WhatsApp**, no por número verificado. Si varios contactos tienen el mismo nombre podría coincidir incorrectamente: usa contactos de prueba con nombres únicos y no habilites autoenvío de forma indiscriminada.
- No contiene IA generativa ni sincronización entre dispositivos. La detección de temas es local mediante reglas; panel web local y APK guardan datos separados. No hay servidor, API de WhatsApp ni pagos mensuales.
- Android no necesita permiso de Internet para usar la app local. Se requiere el permiso especial de acceso a notificaciones si deseas procesarlas. No guarda ni envía imágenes automáticamente.

## Configurar de forma segura

1. **Respuestas automáticas →** deja los dos autoenvíos apagados; enciende la recepción del WhatsApp que probarás.
2. **Contactos y excepciones →** autoriza únicamente un contacto propio con nombre visible único y su WhatsApp correcto.
3. **Asistentes →** usa «Detectar negocio» en ambos WhatsApp o configura una excepción por contacto.
4. **Horarios y festivos →** comprueba horarios por área (ventas/soporte/pedidos) y cierres especiales.
5. **Simulador →** verifica cómo responde el negocio y la fecha elegidos.
6. En Android abre el **permiso de notificaciones** y otórgalo a AutoResponder Pro.
7. Regresa a **Respuestas automáticas**, activa el autoenvío solo para el WhatsApp y contacto de prueba. Un toque en «Detener autoenvío» lo apaga en ambos.
8. Comprueba el resultado desde la bandeja. **No uses inicialmente las cuentas con clientes reales** ni asumas que una respuesta fue entregada.

## Compilar

Java 17, Android SDK 35, Gradle 8.11.1, Android Gradle Plugin 8.9.2.

```bash
cd android
gradle testDebugUnitTest assembleDebug
```

La versión de depuración del APK es para pruebas, no para distribución comercial. No incluye secretos ni datos personales. Se puede compilar con GitHub Actions usando su cuota gratuita para ejecutores estándar en repositorios públicos; verifica límites de tu plan.
