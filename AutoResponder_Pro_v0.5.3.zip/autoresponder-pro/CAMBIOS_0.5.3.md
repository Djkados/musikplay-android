# AutoResponder Pro 0.5.3

- Diagnóstico en Android: permisos, conexión, captura por canal y respuesta automática por canal.
- Último evento recibido y causa de bloqueo, sin guardar textos ni contactos en el diagnóstico.
- Bandeja muestra el motivo real por el que el motor nativo descartó la respuesta.
- Botón para autorizar el remitente directamente desde una notificación capturada.
- Se preservan límites de frecuencia y envío desactivado por defecto.
- Continua el ajuste de barras del sistema de la versión 0.5.2.
