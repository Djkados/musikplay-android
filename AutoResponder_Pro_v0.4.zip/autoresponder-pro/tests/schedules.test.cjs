const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const engine=require('../web/schedule-engine.js');
const scheduled=engine.defaultSchedules();
const local=(s)=>engine.parseBogotaLocal(s);
const at=(assistant,unit,s,overrides=[])=>engine.evaluate(scheduled,overrides,assistant,unit,local(s));

// Business-specific schedules — Colombia time, inclusive start and exclusive end.
assert.equal(at('movieplay','sales','2026-10-11T21:59').open,true);
assert.equal(at('movieplay','sales','2026-10-11T22:00').open,false);
assert.equal(at('movieplay','support','2026-10-11T16:59').open,true);
assert.equal(at('movieplay','support','2026-10-11T17:00').open,false);
assert.equal(at('movieplay','support','2026-10-10T21:59').open,true);
assert.equal(at('tresm','orders','2026-10-10T17:59').open,false);
assert.equal(at('tresm','orders','2026-10-10T18:00').open,true);
assert.equal(at('tresm','orders','2026-10-10T22:30').open,false);
assert.equal(at('tresm','orders','2026-10-12T19:00').open,false);
// Colombian Monday holiday: sales remains open until 22:00; support closes 17:00.
assert.equal(engine.holidays(2026).find(x=>x.date==='2026-10-12')?.name,'Día de la Raza');
assert.equal(at('movieplay','sales','2026-10-12T19:00').open,true);
assert.equal(at('movieplay','support','2026-10-12T19:00').open,false);
assert.equal(at('movieplay','support','2026-10-12T16:59').open,true);
assert.equal(at('movieplay','support','2026-04-02T19:00').open,false); // Jueves Santo
assert.equal(at('movieplay','support','2026-04-04T19:00').open,true); // sábado normal
// A single special closure must not close other workstreams or channels.
const closure=[{assistant:'tresm',unit:'orders',date:'2026-10-10',mode:'closed',note:'Cierre especial'}];
assert.equal(at('tresm','orders','2026-10-10T19:00',closure).open,false);
assert.equal(at('movieplay','sales','2026-10-10T19:00',closure).open,true);
const extra=[{assistant:'tresm',unit:'orders',date:'2026-10-12',mode:'hours',start:'18:00',end:'20:00'}];
assert.equal(at('tresm','orders','2026-10-12T19:00',extra).open,true);
assert.equal(at('tresm','orders','2026-10-12T20:00',extra).open,false);
assert.equal(engine.validRange('18:00','22:30'),true);
assert.equal(engine.validRange('22:30','18:00'),false);
assert.equal(engine.validRange('25:00','29:30'),false);

const channels={normal:{enabled:true,assistant:'auto'},business:{enabled:true,assistant:'auto'}};
let assigned=(channel,contact,text,exceptions=[])=>engine.resolveAssignment(channel,contact,text,channels,exceptions);
assert.equal(assigned('normal','Ana','¿Cuánto vale Netflix?').assistant,'movieplay');
assert.equal(assigned('business','Pedro','¿Cuánto cuesta una hamburguesa?').assistant,'tresm');
assert.equal(assigned('normal','Pedro','¿Cuál es el horario?').method,'clarify');
assert.equal(assigned('business','Ana','Netflix y hamburguesa').method,'clarify');
assert.equal(assigned('business','Ana','Precio').method,'clarify');
assert.equal(assigned('normal','Cliente','Netflix',[{channel:'normal',contact:'Cliente',assistant:'tresm'}]).assistant,'tresm');
assert.equal(assigned('business','Cliente','Netflix',[{channel:'normal',contact:'Cliente',assistant:'tresm'}]).assistant,'movieplay');

// End-to-end with rules + app safety gate + hours at specified Bogota time.
const js=fs.readFileSync(__dirname+'/../web/app.js','utf8');
const cfg={
 version:1,channel:channels,assistants:{movieplay:{active:true},tresm:{active:true},personal:{active:true}},
 exceptions:[],allowlist:[{channel:'normal',contact:'Prueba'},{channel:'business',contact:'Prueba'}],blocked:[],paused:[],
 rules:[{id:'r1',assistant:'movieplay',keywords:'netflix,horario',response:'Respuesta exclusiva MoviePlay',active:true,imageTag:''},{id:'r2',assistant:'tresm',keywords:'hamburguesa,horario',response:'Respuesta exclusiva Las Tres M',active:true,imageTag:''}],
 images:[],schedules:scheduled,scheduleOverrides:[],settings:{requireAllowlist:true,blockGroups:true,reviewOnly:true},inbox:[]
};
const node=()=>({textContent:'',value:'',innerHTML:'',classList:{add(){},remove(){},toggle(){}},addEventListener(){},querySelectorAll(){return[]}});
const els=new Map();const document={querySelector(s){if(!els.has(s))els.set(s,node());return els.get(s);},querySelectorAll(){return[];},addEventListener(){},createElement(){return node()}};
const store=new Map([['autoresponder_pro_v1',JSON.stringify(cfg)]]);
const context={document,window:{ScheduleEngine:engine,addEventListener(){}},localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v)},console,setTimeout,clearTimeout,Date,Math,URL,Blob,navigator:{},FileReader:function(){},indexedDB:{open(){throw Error('IndexedDB unexpectedly opened')}},confirm:()=>true,prompt:()=>null};
vm.runInNewContext(js,context);
const respond=context.window.AutoResponderTest.respond;
assert.equal(respond('normal','Prueba','Netflix',false,local('2026-10-11T18:00')).reply,'Respuesta exclusiva MoviePlay');
assert.match(respond('normal','Prueba','hamburguesa',false,local('2026-10-12T19:00')).reply,/Las Tres M/);
assert.equal(respond('business','Prueba','Netflix',false,local('2026-10-11T18:00')).status,'open');
assert.equal(respond('business','Prueba','hamburguesa',false,local('2026-10-10T19:00')).status,'open');
assert.equal(respond('normal','Prueba','¿Cuál es el horario?',false,local('2026-10-10T20:00')).requiresSelection,true);
assert.match(respond('normal','Prueba','Netflix y hamburguesa',false,local('2026-10-10T20:00')).reply,/MoviePlay.*Las Tres M/);
assert.match(respond('normal','Prueba','PIN 1234',false,local('2026-10-10T20:00')).reason,/seguridad/);
assert.match(respond('business','Prueba','hamburguesa',false,local('2026-10-10T23:00')).reply,/sábados y domingos/);
assert.equal(respond('business','Prueba','hamburguesa',false,local('2026-10-10T23:00')).image,null);
console.log('OK — 35+ comprobaciones de festivos, horarios, excepciones, separación multiempresa, seguridad y respuestas.');
