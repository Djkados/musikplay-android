package com.autoresponder.pro

import android.app.Notification
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

/** Incoming-notification preview only; no automatic replies, no network access. */
class WhatsAppNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        val channel = when (sbn.packageName) {
            "com.whatsapp" -> "normal"
            "com.whatsapp.w4b" -> "business"
            else -> return
        }
        // Notification capture is independent for the two applications and opt-in.
        if (!getSharedPreferences("capture_config", Context.MODE_PRIVATE).getBoolean(channel, false)) return
        val notification = sbn.notification ?: return
        if (notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (notification.category != Notification.CATEGORY_MESSAGE) return
        val extras = notification.extras
        // Group chats are not captured. WhatsApp can change how notifications are represented.
        if (!extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE).isNullOrBlank()) return
        val contact = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val message = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        if (contact.isBlank() || message.isBlank() || contact.length > 140) return
        if (notification.flags and Notification.FLAG_LOCAL_ONLY != 0 && message.contains("mensajes nuevos", ignoreCase = true)) return
        if (message.length > 1000) return
        if (contact.contains("WhatsApp", ignoreCase = true) && message.contains("mensajes", ignoreCase = true)) return
        // Never retain messages which might contain credentials, PINs or access codes.
        if (Regex("(?i)\\b(otp|c[oó]digo de verificaci[oó]n|password|contrase[nñ]a|pin bancario)\\b").containsMatchIn(message)) return
        // Deduplicate repeat notifications for 5 minutes, but allow a new message later.
        val normalized = "$channel|$contact|$message|${sbn.postTime / 300_000}"
        val id = MessageDigest.getInstance("SHA-256").digest(normalized.toByteArray())
            .take(10).joinToString("") { "%02x".format(it) }
        val prefs = getSharedPreferences("private_inbox", Context.MODE_PRIVATE)
        val items = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        for (i in 0 until items.length()) {
            if (items.optJSONObject(i)?.optString("id") == id) return
        }
        val incoming = JSONObject()
            .put("id",id).put("contact", contact.take(140))
            .put("text", message.take(1000)).put("channel", channel)
            .put("time", System.currentTimeMillis())
        val next = JSONArray().put(incoming)
        for(i in 0 until minOf(29,items.length())) next.put(items.get(i))
        // Local storage, not uploaded. Android notification access requires the user's permission.
        prefs.edit().putString("items", next.toString()).apply()
    }
}
