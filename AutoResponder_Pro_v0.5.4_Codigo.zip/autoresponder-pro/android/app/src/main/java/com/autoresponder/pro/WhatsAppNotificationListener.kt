package com.autoresponder.pro

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

/**
 * Controlled, opt-in notification replies. Text only, with strict contact allowlists.
 * This is NOT a WhatsApp API and WhatsApp may change/disable notification replies.
 * A successful PendingIntent means "submitted to Android", NOT delivered to a recipient.
 */
class WhatsAppNotificationListener : NotificationListenerService() {
    // Diagnostic metadata only; no contact, content, or credentials in this store.
    private fun trace(channel: String, code: String) {
        getSharedPreferences("listener_status", Context.MODE_PRIVATE).edit()
            .putString("lastChannel", channel).putString("lastReason", code)
            .putLong("lastEventAt", System.currentTimeMillis()).apply()
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        val existingWhatsApp = try {
            activeNotifications?.count { it.packageName == "com.whatsapp" || it.packageName == "com.whatsapp.w4b" } ?: 0
        } catch (_: Exception) { 0 }
        getSharedPreferences("listener_status", Context.MODE_PRIVATE).edit()
            .putBoolean("connected", true)
            .putLong("connectedAt", System.currentTimeMillis())
            .putInt("activeWhatsappAtConnect", existingWhatsApp)
            .apply()
    }

    override fun onListenerDisconnected() {
        getSharedPreferences("listener_status", Context.MODE_PRIVATE).edit()
            .putBoolean("connected", false)
            .putLong("disconnectedAt", System.currentTimeMillis()).apply()
        super.onListenerDisconnected()
    }

    private fun fingerprint(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray()).take(12).joinToString("") { "%02x".format(it) }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        val channel = when (sbn.packageName) {
            "com.whatsapp" -> "normal"
            "com.whatsapp.w4b" -> "business"
            else -> return
        }
        // Record ONLY an event counter and its package identity, never message
        // content or sender details. This runs before capture filters so users
        // can distinguish a disconnected listener from an excluded notification.
        val counters = getSharedPreferences("listener_status", Context.MODE_PRIVATE)
        val counterKey = if (channel == "normal") "eventsNormal" else "eventsBusiness"
        counters.edit().putLong(counterKey, counters.getLong(counterKey, 0L) + 1L)
            .putLong("lastWhatsappNoticeAt", System.currentTimeMillis())
            .apply()
        if (!getSharedPreferences("capture_config", Context.MODE_PRIVATE).getBoolean(channel, false)) {
            trace(channel, "capture_off"); return
        }
        val notification = sbn.notification ?: run { trace(channel, "empty_notification"); return }
        if (notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) {
            trace(channel, "notification_summary"); return
        }
        if (notification.category != Notification.CATEGORY_MESSAGE) {
            trace(channel, "not_message_category"); return
        }
        val extras = notification.extras
        // Fail closed on group or summary notifications.
        if (extras.getBoolean("android.isGroupConversation", false)) {
            trace(channel, "group_skipped"); return
        }
        if (!extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE).isNullOrBlank()) {
            trace(channel, "group_skipped"); return
        }
        val contact = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val message = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        if (contact.isBlank() || message.isBlank() || contact.length > 140 || message.length > 1000) {
            trace(channel, "unreadable_message"); return
        }
        if (contact.contains("WhatsApp", ignoreCase = true) && message.contains("mensajes", ignoreCase = true)) {
            trace(channel, "summary_skipped"); return
        }
        if (Regex("(?i)^(tú|you|yo):\\s").containsMatchIn(message)) {
            trace(channel, "own_message_skipped"); return
        }
        if (Regex("(?i)(\\d+ mensajes nuevos|new messages|foto|photo|video|sticker|nota de voz)").matches(message)) {
            trace(channel, "media_skipped"); return
        }
        if (System.currentTimeMillis() - sbn.postTime > 2 * 60 * 1000L) {
            trace(channel, "stale_skipped"); return
        }
        // Prevent retaining messages that may contain secrets or authentication codes.
        val normalized = NativeAutoReplyEngine.normalize(message)
        if (Regex("\\b(otp|codigo de verificacion|codigo de acceso|password|contrasena|pin bancario|clave dinamica)\\b").containsMatchIn(normalized)) {
            trace(channel, "sensitive_skipped"); return
        }
        val key = fingerprint("$channel|$contact|$message")
        val prefs = getSharedPreferences("private_inbox", Context.MODE_PRIVATE)
        val seen = getSharedPreferences("recent_notifications", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now - seen.getLong(key,0L) < 5 * 60 * 1000L) {
            trace(channel, "duplicate_skipped"); return
        }
        // A reissued notification may represent the same message. Mark it before acting.
        seen.edit().putLong(key,now).apply()
        val items = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        val incoming = JSONObject().put("id",fingerprint("$key|$now")).put("contact",contact)
            .put("text",message).put("channel",channel).put("time",now)
        val configString = getSharedPreferences("automation_rules", Context.MODE_PRIVATE).getString("config", null)
        if (configString == null) incoming.put("autoStatus", "no_rules_config")
        if (configString != null) {
            try {
                val config = JSONObject(configString)
                val decision = NativeAutoReplyEngine.decide(config,channel,contact,message)
                incoming.put("assistant",decision.business ?: JSONObject.NULL)
                    .put("department",decision.department ?: JSONObject.NULL)
                    .put("autoReason", decision.reason)
                if (decision.text != null) {
                    // At most one auto-submission per conversation every 10 minutes.
                    val throttle = getSharedPreferences("reply_throttle", Context.MODE_PRIVATE)
                    val conversationKey=fingerprint("$channel|$contact")
                    if (now - throttle.getLong(conversationKey,0L) < 10 * 60 * 1000L) {
                        incoming.put("autoStatus","throttled")
                    } else {
                        val action = notification.actions?.firstOrNull { a ->
                            a.remoteInputs?.any { it.allowFreeFormInput } == true && a.actionIntent != null
                        }
                        if (action == null) {
                            incoming.put("autoStatus","no_quick_reply")
                        } else if (throttle.edit().putLong(conversationKey,now).commit()) {
                            val inputs = action.remoteInputs.filter { it.allowFreeFormInput }.toTypedArray()
                            try {
                                val bundle = Bundle()
                                inputs.forEach { bundle.putCharSequence(it.resultKey,decision.text) }
                                val intent = Intent().addFlags(Intent.FLAG_RECEIVER_FOREGROUND)
                                RemoteInput.addResultsToIntent(inputs,intent,bundle)
                                action.actionIntent.send(this,0,intent)
                                incoming.put("autoStatus","submitted_unverified")
                                    .put("autoText",decision.text.take(1600))
                            } catch (_: PendingIntent.CanceledException) {
                                incoming.put("autoStatus","failed_canceled")
                            } catch (_: SecurityException) {
                                incoming.put("autoStatus","failed_permission")
                            } catch (_: Exception) {
                                incoming.put("autoStatus","failed")
                            }
                        } else incoming.put("autoStatus","failed_storage")
                    }
                } else incoming.put("autoStatus","skipped")
            } catch (_: Exception) {
                incoming.put("autoStatus","failed_config")
            }
        }
        val next = JSONArray().put(incoming)
        for (i in 0 until minOf(49,items.length())) next.put(items.get(i))
        // Only latest 50 notifications kept locally. No network permissions, no uploads.
        prefs.edit().putString("items",next.toString()).apply()
        trace(channel, incoming.optString("autoStatus", "captured"))
    }
}
