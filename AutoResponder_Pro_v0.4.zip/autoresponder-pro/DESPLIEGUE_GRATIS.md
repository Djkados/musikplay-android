# AutoResponder Pro 0.4 — Compilación gratuita y sin sorpresas

## APK
El proyecto usa Android SDK 35, Gradle 8.11.1 y Java 17. Para obtener el APK: crea un repositorio público nuevo de GitHub **sin información de clientes ni credenciales** y sube esta carpeta como raíz. En la pestaña Actions ejecuta el workflow **AutoResponder Pro - Compilar APK gratis**. Descarga el artefacto `AutoResponderPro-v0.4-debug-APK` y extrae `app-debug.apk` para instalarlo. Alternativamente abre `android/` en Android Studio y usa Build > Build APK(s).

En GitHub, los ejecutores estándar de Actions son gratuitos para repositorios públicos. Un repositorio privado consume cuota y puede generar cobros si se supera; evita activar gastos y establece límite presupuestal de $0. No se habilitan runners especiales ni servicios externos.

## Panel web
El panel HTML funciona **localmente y sin servidor**. Para abrirlo en cualquier computador, abre `AutoResponder_Pro_Demo.html`. Esto no sincroniza la configuración con Android automáticamente; usa Exportar/Importar configuración. Al estar basado en HTML/JS local, **no publiques datos de clientes o credenciales** en sitios públicos.

Se puede alojar gratuitamente el panel estático en GitHub Pages/Cloudflare Pages, pero **un panel administrativo con datos reales exige autenticación y backend seguro**. No hay sincronización remota en este prototipo. No se contrataron servicios, se publicaron sitios ni se generan cobros desde el proyecto.

## Límites y seguridad
Solo notificaciones, reglas locales, preparación de texto e imágenes y envío manual por WhatsApp. No utiliza API de Meta ni IA generativa. Los canales de captura están apagados inicialmente. La instalación de un APK de prueba instala únicamente AutoResponder Pro; no modifica WhatsApp normal/Business. Requiere probar permisos de notificaciones con contactos voluntarios; no garantizar que las notificaciones de WhatsApp lleguen siempre ni ausencia de restricciones.
