# Pruebas de aceptación — AutoResponder Pro 0.3

## Horarios y mezcla entre negocios

| ID | Entrada | Resultado esperado |
|---|---|---|
| H01 | WhatsApp normal: «Netflix» | Asistente MoviePlay aunque el canal también atienda Las Tres M |
| H02 | WhatsApp Business: «hamburguesa» | Asistente Las Tres M aunque Business también atienda MoviePlay |
| H03 | Cualquiera: «¿cuál es el horario?» | Pregunta para qué negocio, sin atribuir horario incorrecto |
| H04 | Cualquiera: «Netflix y hamburguesa» | Consulta mixta: pide aclaración |
| H05 | MoviePlay Ventas, domingo 18:00 | Abierto (cierra a las 22:00) |
| H06 | MoviePlay Soporte, domingo 18:00 | Fuera de horario (cierra a las 17:00) |
| H07 | MoviePlay Soporte, lunes festivo 19:00 | Fuera de horario por festivo nacional |
| H08 | MoviePlay Ventas, lunes festivo 19:00 | Abierto |
| H09 | Las Tres M, sábado 18:00 | Abierto |
| H10 | Las Tres M, sábado 22:30 | Cerrado |
| H11 | Las Tres M, lunes 19:00 | Cerrado, aunque sea festivo |
| H12 | Excepción de cierre solo Las Tres M sábado | Las Tres M cerrado; MoviePlay sigue abierto |
| H13 | Excepción de apertura Las Tres M lunes festivo | Las Tres M abierto en el horario especial |
| H14 | Contacto asignado explícitamente a Las Tres M en normal | Respeta la excepción y no usa reglas de MoviePlay |
| H15 | El mismo contacto en Business sin excepción | La excepción de normal no se traslada a Business |
| H16 | Editar un horario de soporte | No altera ventas ni Las Tres M |
| H17 | Editar mensaje fuera de horario Las Tres M | No altera la respuesta de MoviePlay |
| H18 | Abrir secciones plegables en móvil | No hay desbordamientos; cambios persisten localmente |

## Seguridad, imágenes y Android (requieren pruebas reales)

| ID | Escenario | Resultado esperado |
|---|---|---|
| A01 | Instalación nueva Android | Ambos canales apagados |
| A02 | Activar un solo canal | No se capturan notificaciones del otro |
| A03 | Contacto sin autorización | No hay sugerencia en modo de pruebas |
| A04 | Contacto excluido, grupo o PIN/OTP | No se genera respuesta |
| A05 | Imagen de MoviePlay vigente | Puede sugerirse solamente para MoviePlay |
| A06 | Imagen caducada o de otra empresa | Nunca se sugiere |
| A07 | Abrir compartir y cancelar | No se afirma entrega ni envío |
| A08 | Compartir con WhatsApp normal | Se abre el paquete correcto para confirmar |
| A09 | Compartir con WhatsApp Business | Se abre el paquete correcto para confirmar |
| A10 | Sin internet | Panel local funciona; reglas locales disponibles |
| A11 | Exportar JSON | Incluye horarios y cierres, **no** archivos multimedia |
| A12 | Dos notificaciones próximas | No se intercambian los contactos o las imágenes |

**Estado:** probadas las comprobaciones automatizadas de código y la interfaz web. Las pruebas de Android real A01–A12 están pendientes hasta compilar e instalar el APK.
